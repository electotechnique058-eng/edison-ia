# Novi IA — carnet de projet (sauvegarde mise à jour le 14 octobre 2026)

## Qui et pourquoi
- Créateur : Edison Ahodede, électrotechnicien (Bénin).
- Il rêve de bâtir quelque chose de plus grand. Il a choisi Thomas Edison comme idole et veut être comme lui.
- Novi IA ne doit jamais quémander (pas de « cherche des collaborateurs / du soutien »).

## Objectifs d'Novi IA (à ne pas oublier)
1. Aider à apprendre et résoudre des problèmes d'électricité, d'électrotechnique et de solaire.
2. Enseigner les énergies renouvelables, les centrales, le code et la culture générale.
3. Respecter les bonnes manières (salutations, politesse).
4. Retenir ce qu'on lui apprend (commande Python : `apprends : question = réponse`).
5. Devenir une vraie assistante IA : comprendre le sens des questions, calculer, écouter et parler.

## Où est tout
- Application en ligne : https://electotechnique058-eng.github.io/edison-ia/
- Code sur GitHub : https://github.com/electotechnique058-eng/edison-ia
- Dans ce dossier (les fiches sont déjà dans index.html et dans le fichier Python) :
  - `edison-ia-site/` : les 5 fichiers de l'application (index.html, manifest.json, sw.js, icon-192.png, icon-512.png)
  - `python/novi_android_gui_v21_machines.py` : version Python (Pydroid 3)

## Mettre à jour l'application
1. Remplacer les fichiers dans le dépôt GitHub : Add file > Upload files > mêmes noms > Commit changes.
2. Attendre 1 à 2 minutes, puis rouvrir l'application avec Internet.
3. Nom sous l'icône : « Novi IA » (manifest.json).

## Ce qu'Novi sait déjà
- Électrotechnique : câbles, disjoncteurs, moteurs (direct, étoile-triangle), schémas, dépannage, mesure, sécurité, couleurs des fils, normes.
- Solaire : dimensionnement, régulateur, vidéosurveillance, antenne parabolique.
- Énergie : renouvelables, production de courant, centrales, rendement, stockage.
- Code : Python, HTML/CSS/JS, débogage, Arduino.
- Culture générale : salutations, politesse, Bénin, géographie.
- Schémas affichés : démarrage direct, étoile-triangle, va-et-vient, installation solaire.
- Schémas des cours 2nde et 1ère (≈ 60, dessinés par le code, clair/sombre) : circuits, lois des nœuds et mailles, associations, générateur/récepteur, Thévenin/Norton/Millman/Kennelly, pile Daniell, diode (symbole, polarisation, caractéristique, modèles), Zener, Coulomb, champ, condensateur (plan, charge RC), sinusoïdes, déphasage, Fresnel, impédances, RLC, résonance, puissances, triphasé étoile/triangle, transistor, AOP (inverseur, non inverseur, suiveur, sommateur), aimant, solénoïde, Lorentz, Laplace, hystérésis, induction. Novi les montre sur demande (« schéma de … », « dessine … ») ET automatiquement sous chaque explication du cours. Site seulement (Python ne sait pas dessiner).
- Moteurs et machines (14 oct. 2026) : 16 fiches (types de moteurs, asynchrone, cage, rotor bobiné, Dahlander / enroulements séparés, plaque à bornes et couplages, démarrages, bilan de puissances, synchrone, alternateur, courant continu, génératrice, monophasé, essais de laboratoire, appareils de mesure, protection) + 13 schémas dessinés (coupe du moteur, rotor à cage, plaque à bornes Y/Δ, démarrage rotorique, Dahlander, MCC et excitations, alternateur, bilan, courbe couple-vitesse, deux wattmètres, mesures, circuit de puissance).
- Salutations corrigées (« salut, comment ça va ? » → réponse complète) ; « explique X » et « X » donnent la même réponse du cours.
- Personne ajoutée : Yegbegnon Gédéon (électrotechnicien, LYTEB ; éloge fourni par Edison). À compléter quand Edison enverra le reste de la description.
- Calculateurs pas à pas (site) : puissance mono/tri/continu, courant, loi d'Ohm, résistors/condensateurs série/parallèle, diviseur de tension, résistance d'un fil, moteur (courant absorbé, glissement, vitesse de synchronisme, couple, rendement), section de câble et calibre, chute de tension, relèvement du cos φ, énergie et coût, RC, RLC. Exemple : « calcule le courant d'un moteur triphasé 5,5 kW 400 V cos phi 0,85 rendement 88 % ».
- Quiz et exercices corrigés : « donne-moi un quiz », « quiz sur les moteurs », « exercice de calcul sur la puissance triphasée » ; réponses A/B/C/D ou chiffres ; « solution », « suivant », « stop ».
- Compréhension souple (site) : tolère les fautes de frappe (« condensatueur », « relai »), les synonymes, les pluriels ; propose des sujets proches quand il n'est pas sûr ; questions de suivi (« un exemple », « résume », « plus de détails »).
- Personne ajoutée : Aidego Ange Bignon (électrotechnicien, études de maintenance des systèmes industriels à Lokossa, ami d'Edison depuis la seconde).
- Voix : micro et lecture (Chrome, Internet nécessaire pour comprendre la voix).
- Histoire et personnes : famille AHODEDE d'Abomey (ancêtres amenés par le roi Guezo, fidèles et prêtres de Fâ), roi Guezo (faits vérifiés), Rodriguez Paul (BTP / génie civil).
- Réponses courtes à merci / ok, et des blagues avec emojis.

- Physique (chapitre M1, cinématique) : fiches de cours (repères, vitesse, accélération, MRU, MRUV, MCU, unités S.I.) et calculs avec étapes (v = at + v0, x = ½at² + v0t + x0, v² − v0² = 2a(x − x0), v = Rω, a = v²/R, T, N), rencontre de deux mobiles, dérivées de x(t).
- Photos : bouton 📷 dans le site (lecture du texte imprimé par OCR, Internet requis la 1re fois ; le texte lu est placé dans la zone de saisie pour être vérifié) ; dans le Python, commande `image /chemin/photo.jpg` (clé API requise).
- LYTEB (Lycée Technique et Professionnel de Bohicon) : fiches d'identification, mission, événements 2013, 2023, 2025 et 2026 ; Novi n'invente jamais la date de création, le fondateur ni le premier directeur (informations non confirmées).
- Module commercial : Novi présente les services de son concepteur seulement sur demande directe ou après accord de l'utilisateur (une proposition par session) ; coordonnées dans la constante COM (site : index.html ; Python : edison_android_gui_v16_commerce.py). Aucune info inventée : tarif, diplômes, références, garantie et disponibilité restent « à confirmer ».
- Schéma solaire illustré (site seulement) : demande « dessine un schéma solaire avec 4 panneaux » ou « ... sans onduleur » ; dessiné par le code (panneaux, contrôleur MPPT, fusible, batterie, interrupteur, onduleur, charges DC et AC).
- Guide illustré des schémas (PDF du créateur) : 23 fiches (éclairage, prise et terre, démarrages de moteurs, protections, diagnostic, glossaire…) dans le site et dans le Python.
- Schémas dessinés par le code (site) : démarrage direct avec commande marche/arrêt, inversion de sens, transformateur et couplage Dyn, tableau de maison (valeurs NF C 15-100 à vérifier selon les règles locales).
- Comptes (site) : création de compte / connexion / « Continuer sans compte » ; comptes enregistrés sur le téléphone (mot de passe haché PBKDF2, mémoire séparée par compte, le 1er compte récupère la mémoire existante) ; message de bienvenue personnalisé ; pas de récupération de mot de passe ni de synchronisation entre appareils.
- Appel vocal en direct : bouton 📞 (site, Chrome sur Android, Internet requis pour la reconnaissance vocale) et bouton « 📞 Appel » (Python, fenêtre vocale Android) ; Novi écoute, répond à voix haute, puis écoute à nouveau ; « au revoir » ou « Raccrocher » termine l'appel.
- Cours d'électrotechnique de M. Gildas Zonakpo (LYTEB) : 90 fiches (2nde F3/EL : circuits CC, Kirchhoff/Thévenin/Norton/Millman/Kennelly, piles et accumulateurs, diodes et Zener, électrostatique, condensateurs ; 1ère F3/EL : grandeurs sinusoïdales, Fresnel et complexes, RLC et résonance, puissances et cos φ, triphasé, transistors, AOP, magnétisme, Lorentz/Laplace, ferromagnétisme, induction, auto-induction). Demander par exemple « loi des mailles », « résonance », « couplage étoile ». Les exercices des PDF ne sont pas corrigés (le cours n'en donne pas les corrigés) : les exemples chiffrés des fiches sont vérifiés par calcul, mais à confirmer avec le professeur.
- Barre de saisie refaite (site) : grande zone de texte en haut, boutons en dessous.

## Idées pour la suite
- Plus de fiches (prix du matériel au Bénin, cours, exercices corrigés).
- Schémas : inversion de sens d'un moteur, tableau électrique d'une maison.
- Quiz d'entraînement.
- Lecture d'images plus poussée (schémas, écriture à la main) : demande l'IA avec clé API.

## Sécurité
- Le dépôt GitHub est public : ne jamais y mettre de clé API ni de mot de passe.
- Vérifier chaque valeur technique avec les cours et les normes locales avant de l'appliquer.

## Pour continuer avec Claude (même après changement de téléphone)
1. Se connecter au même compte Claude : les conversations restent dans le compte.
2. Dans une nouvelle conversation, envoyer ce dossier (ou au moins `index.html` et ce fichier LISEZ-MOI) et écrire ce qu'on veut ajouter.
3. Garder une copie de ce dossier dans un endroit sûr (Google Drive, e-mail, carte mémoire).


## Version 32 : Bénin
- 29 fiches : présentation, géographie, superficie/population, 12 départements, villes, drapeau et symboles, histoire, royaume du Dahomey, gouvernement et président, langues et ethnies, expressions en fon, vodun et religions, fêtes, cuisine, culture et personnalités, tourisme (Ouidah, Abomey, Ganvié, Pendjari, Atacora, Porto-Novo, Cotonou), conseils de voyage, économie, électricité, éducation.
- Schémas : carte du Bénin et drapeau (site).
- Site : remplace index.html sur GitHub. Python : novi_android_gui_v22_benin.py.
- Les infos du gouvernement peuvent changer : vérifier sur gouv.bj.


## Version 33 : base élargie (93 fiches)
- Maintenance industrielle : types et niveaux, MTBF/MTTR/disponibilité, GMAO, AMDEC, TPM/5S, TRS, outils qualité, consignation et habilitations, lubrification et roulements, vibrations/thermographie, transmission, pompes, pneumatique/hydraulique, méthode de dépannage.
- Génie électrique : transformateurs, réseaux, régimes de neutre, protections, section de câble, bilan de puissance, éclairage, redressement/hacheur/onduleur, variateurs, groupe électrogène, dimensionnement solaire, sécurité, moteur monophasé, énergies renouvelables, outillage.
- Électronique : codes couleurs, composants, LED, transistors/MOSFET, thyristor/triac, NE555, logique, bascules, binaire/hexa, Arduino, ESP32, capteurs, alimentations/batteries, mesures, soudure/PCB, filtres, CEM, Raspberry Pi.
- Automatisme : API, Ladder, GRAFCET, schémas et repérage, commande de moteurs, PID, supervision/bus de terrain, robotique.
- Sciences : maths, fonctions, complexes, statistiques, mécanique, chaleur/froid, optique/ondes, chimie, matériaux, dessin technique, métrologie.
- Culture : informatique, internet, programmation, IA et cybersécurité, histoire de l'Afrique et du monde, géographie du monde, économie, création d'entreprise, emploi/CV, orientation, santé, droit et démarches au Bénin, méthodes de travail, rédaction.
- Langues : vocabulaire électrique anglais, grammaire anglaise, phrases utiles, anglais professionnel, conjugaison, orthographe, yoruba.
- Site : remplace index.html sur GitHub. Python : novi_android_gui_v23_base.py.
- Les infos de santé, de droit et de démarches sont générales : à vérifier auprès des services officiels.
