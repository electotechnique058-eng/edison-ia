# -*- coding: utf-8 -*-
"""
EDISON AI V12
Assistante IA pour Pydroid 3 / Android (texte + voix + IA Claude via internet).
- Mémoire persistante dans memoire.json
- Calculs sûrs
- Calculs de coûts de matériel
- Connaissances électrotechniques de base
- Recherche locale dans les connaissances
- Commandes simples et dialogue
- V12 : énergies renouvelables, centrales, programmation, culture générale, politesse,
  identité du créateur et commande « apprends : question = réponse »
"""

import ast
import copy
import json
import math
import operator
import os
import queue
import re
import threading
import unicodedata
import urllib.error
import urllib.request
from datetime import datetime

# ---------------- VOIX ANDROID / PYDROID 3 ----------------
# Edison fonctionne toujours en texte si les fonctions vocales ne sont pas disponibles.
try:
    import androidhelper
except ImportError:
    androidhelper = None

try:
    from jnius import autoclass
except ImportError:
    autoclass = None

ANDROID_DROID = None

def initialiser_voix():
    """Prépare les fonctions vocales Android sans bloquer Edison si elles sont absentes."""
    global ANDROID_DROID
    if ANDROID_DROID is not None:
        return ANDROID_DROID
    if androidhelper is not None:
        try:
            ANDROID_DROID = androidhelper.Android()
            return ANDROID_DROID
        except Exception:
            pass
    return None

def parler(texte):
    """Lit une réponse à voix haute en français sur Android."""
    droid = initialiser_voix()
    if droid is None:
        return False
    try:
        # Évite de lire des marqueurs purement techniques.
        texte = re.sub(r"```.*?```", "", str(texte), flags=re.S).strip()
        if not texte:
            return False
        # Prononciation du nom AHODEDE : A-O-dé-dè
        texte = re.sub(r"ahod[eéè]d[eéè]", "Aodédè", texte, flags=re.I)
        droid.ttsSpeak(texte)
        return True
    except Exception:
        return False

def ecouter_voix():
    """Reconnaît une phrase prononcée par l'utilisateur, en français."""
    droid = initialiser_voix()
    if droid is None:
        return None, "La reconnaissance vocale Android n'est pas disponible dans cet environnement."
    try:
        resultat = droid.recognizeSpeech(
            "Parle à Edison",
            "fr-FR",
            None
        )
        # SL4A renvoie généralement {'result': [...]}.
        if isinstance(resultat, dict):
            valeurs = resultat.get("result") or resultat.get("RESULTS") or []
            if isinstance(valeurs, list) and valeurs:
                phrase = str(valeurs[0]).strip()
                if phrase:
                    return phrase, None
        return None, "Je n'ai pas compris. Réessaie en parlant plus clairement."
    except Exception as exc:
        return None, f"Impossible d'utiliser le microphone : {exc}"

MEMORY_FILE = "memoire.json"

DEFAULT_MEMORY = {
    "informations": {},
    "connaissances": {},
    "historique": []
}

# ---------------- MÉMOIRE ----------------

def charger_memoire():
    if not os.path.exists(MEMORY_FILE):
        sauvegarder_memoire(DEFAULT_MEMORY)
        return copy.deepcopy(DEFAULT_MEMORY)

    try:
        with open(MEMORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Réparer automatiquement un ancien fichier incomplet
        for key, default in DEFAULT_MEMORY.items():
            if key not in data or not isinstance(data[key], type(default)):
                data[key] = default.copy() if isinstance(default, dict) else list(default)
        return data

    except (json.JSONDecodeError, OSError):
        # On ne détruit pas silencieusement l'ancien fichier :
        # on repart avec une mémoire propre.
        return copy.deepcopy(DEFAULT_MEMORY)


def sauvegarder_memoire(data):
    temp = MEMORY_FILE + ".tmp"
    with open(temp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(temp, MEMORY_FILE)


memoire = charger_memoire()


def retenir(cle, valeur):
    memoire["informations"][cle.strip().lower()] = valeur.strip()
    sauvegarder_memoire(memoire)


def oublier(cle):
    cle = cle.strip().lower()
    if cle in memoire["informations"]:
        del memoire["informations"][cle]
        sauvegarder_memoire(memoire)
        return True
    return False


# ---------------- CALCULATEUR SÛR ----------------

OPERATEURS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}


def calculer(expression):
    """Évalue seulement des opérations mathématiques, sans eval()."""
    expression = expression.replace("×", "*").replace("÷", "/").replace("^", "**")
    expression = expression.replace(",", ".").strip()

    if len(expression) > 120:
        raise ValueError("Expression trop longue.")

    arbre = ast.parse(expression, mode="eval")

    def eval_noeud(noeud):
        if isinstance(noeud, ast.Constant) and isinstance(noeud.value, (int, float)):
            return noeud.value

        if isinstance(noeud, ast.UnaryOp) and type(noeud.op) in OPERATEURS:
            return OPERATEURS[type(noeud.op)](eval_noeud(noeud.operand))

        if isinstance(noeud, ast.BinOp) and type(noeud.op) in OPERATEURS:
            gauche = eval_noeud(noeud.left)
            droite = eval_noeud(noeud.right)

            # Protection contre les calculs absurdes
            if isinstance(noeud.op, ast.Pow) and abs(droite) > 20:
                raise ValueError("Puissance trop grande.")
            return OPERATEURS[type(noeud.op)](gauche, droite)

        raise ValueError("Expression non autorisée.")

    return eval_noeud(arbre.body)


# ---------------- OUTILS ----------------

def normaliser(texte):
    return re.sub(r"\s+", " ", texte.lower().strip())


def format_nombre(n):
    if isinstance(n, float) and n.is_integer():
        return str(int(n))
    return str(round(n, 6))


def ajouter_historique(question, reponse):
    memoire["historique"].append({
        "date": datetime.now().isoformat(timespec="seconds"),
        "question": question,
        "reponse": reponse
    })
    # On garde seulement les 50 derniers échanges pour rester léger.
    memoire["historique"] = memoire["historique"][-50:]
    sauvegarder_memoire(memoire)


# ---------------- ÉLECTROTECHNIQUE ----------------

CONNAISSANCES = {
    "loi d ohm": "Loi d'Ohm : U = R × I. Donc I = U/R et R = U/I.",
    "puissance courant continu": "En courant continu : P = U × I.",
    "puissance monophasé": "En monophasé : P = U × I × cos(phi).",
    "puissance triphasé": "En triphasé équilibré : P = √3 × U × I × cos(phi).",
    "energie": "Énergie électrique : E = P × t. Si P est en kW et t en heures, E est en kWh.",
    "moteur": "Pour diagnostiquer un moteur : vérifier alimentation, protections, continuité, isolement, connexions, courant absorbé et état mécanique.",
    "api": "Un API (automate programmable industriel) reçoit des entrées, exécute un programme et commande des sorties.",
    "maintenance": "La maintenance préventive consiste à intervenir avant la panne selon un programme. La corrective intervient après une défaillance.",
    "disjoncteur": "Un disjoncteur protège principalement contre les surintensités et, selon le type, peut aussi intégrer une protection différentielle.",
    "transformateur": "Un transformateur AC modifie un niveau de tension/courant par induction électromagnétique, à fréquence essentiellement constante.",
}


# ---------------- CONNAISSANCES PHOTOVOLTAIQUES HORS LIGNE ----------------
# Fiches pedagogiques generales. Elles peuvent etre enrichies avec les cours
# de l'utilisateur. Elles ne remplacent pas le dimensionnement professionnel.

CONNAISSANCES_PHOTOVOLTAIQUE = [
    {
        "titre": "Fonctionnement du photovoltaique",
        "cles": ["photovoltaique", "electricite solaire", "energie solaire",
                 "fonctionne un panneau solaire", "panneau photovoltaique"],
        "reponse": (
            "Le photovoltaique transforme une partie de la lumiere en electricite "
            "grace aux cellules des modules solaires. Une installation peut comprendre "
            "des modules, des cables et protections, un regulateur, une batterie si "
            "le stockage est necessaire, et un onduleur si du courant alternatif est requis. "
            "La production varie selon l'ensoleillement, la temperature, l'orientation, "
            "les ombrages et les pertes."
        )
    },
    {
        "titre": "Puissance d'un panneau solaire",
        "cles": ["puissance panneau", "watt crete", "w c", "puissance solaire",
                 "module solaire", "panneau solaire"],
        "reponse": (
            "La puissance nominale d'un module est souvent indiquee en watt-crete (Wc), "
            "mesuree dans des conditions normalisees. La puissance reelle depend des "
            "conditions sur le terrain. Le Wc mesure une puissance, tandis que le Wh "
            "ou le kWh mesure une energie produite ou consommee."
        )
    },
    {
        "titre": "Cellule photovoltaique",
        "cles": ["cellule photovoltaique", "cellule solaire", "silicium"],
        "reponse": (
            "Une cellule photovoltaique est un composant qui convertit une partie de "
            "l'energie lumineuse en energie electrique. Plusieurs cellules sont assemblees "
            "dans un module. Les performances dependent notamment de la technologie, "
            "de l'eclairement et de la temperature."
        )
    },
    {
        "titre": "Courant continu et alternatif",
        "cles": ["courant continu", "courant alternatif", "difference courant",
                 "dc ac", "convertir courant"],
        "reponse": (
            "Les modules photovoltaiques produisent du courant continu (CC/DC). "
            "Un onduleur convertit ce courant en courant alternatif (CA/AC) lorsque "
            "les appareils ou le reseau le necessitent. Il faut respecter les tensions, "
            "puissances et limites indiquees par les fabricants."
        )
    },
    {
        "titre": "Onduleur solaire",
        "cles": ["onduleur", "role de l onduleur", "a quoi sert un onduleur"],
        "reponse": (
            "Un onduleur convertit le courant continu en courant alternatif. Son choix "
            "depend notamment de la tension d'entree, de la puissance des charges, des "
            "pointes de demarrage et de la compatibilite avec les panneaux ou batteries. "
            "Il faut respecter les caracteristiques et protections recommandees par le fabricant."
        )
    },
    {
        "titre": "Batterie solaire et autonomie",
        "cles": ["batterie solaire", "stockage energie", "capacite batterie",
                 "autonomie batterie", "dimensionner batterie"],
        "reponse": (
            "Une batterie stocke l'energie pour une utilisation ulterieure. Pour l'evaluer, "
            "il faut connaitre la consommation journaliere, la tension, l'autonomie recherchee, "
            "la profondeur de decharge autorisee, le rendement et la technologie. La capacite "
            "nominale n'est pas toujours entierement utilisable. Suivre les recommandations "
            "du fabricant pour la charge, la protection et l'installation."
        )
    },
    {
        "titre": "Panneaux en serie",
        "cles": ["montage en serie", "panneaux en serie", "tension serie"],
        "reponse": (
            "Dans un montage en serie, les tensions des modules s'additionnent et le courant "
            "de la chaine depend des conditions de fonctionnement et des modules. Il faut "
            "verifier que la tension maximale, notamment par temps froid, reste dans les "
            "limites de l'onduleur ou du regulateur."
        )
    },
    {
        "titre": "Panneaux en parallele",
        "cles": ["montage en parallele", "panneaux en parallele", "courant parallele"],
        "reponse": (
            "Dans un montage en parallele, les courants des branches s'additionnent lorsque "
            "les tensions sont compatibles. La tension reste approximativement celle d'une "
            "branche identique. Les protections, les sections de cable et les limites du "
            "regulateur doivent etre verifiees."
        )
    },
    {
        "titre": "Calcul de puissance et d'energie solaire",
        "cles": ["production solaire", "calcul production panneau", "energie produite",
                 "dimensionner panneaux", "heures de soleil", "consommation journaliere"],
        "reponse": (
            "Pour une premiere estimation : energie journaliere (kWh) ≈ puissance des "
            "panneaux (kWc) × heures equivalentes de soleil × facteur global de performance. "
            "Cette estimation n'est pas un dimensionnement complet : il faut des donnees "
            "locales fiables et tenir compte de la meteo, de l'orientation, de la temperature, "
            "des ombrages et des pertes. Ne choisis pas ces valeurs au hasard pour une installation reelle."
        )
    },
    {
        "titre": "Ombrage des panneaux",
        "cles": ["ombrage", "ombre panneau", "arbre panneau solaire", "ombre solaire"],
        "reponse": (
            "L'ombrage peut reduire la production photovoltaique. Avant la pose, examine "
            "les ombres des arbres, batiments et obstacles a differents moments de la journee. "
            "L'effet depend de la configuration des modules et de l'electronique utilisee."
        )
    },
    {
        "titre": "Temperature des panneaux",
        "cles": ["temperature panneau", "chaleur panneau", "rendement temperature",
                 "panneau chaud"],
        "reponse": (
            "Pour de nombreux modules au silicium, une temperature de cellule plus elevee "
            "reduit la tension et peut reduire la puissance par rapport aux conditions de reference. "
            "Consulte la fiche technique, notamment le coefficient de temperature du module."
        )
    },
    {
        "titre": "Maintenance photovoltaique",
        "cles": ["maintenance solaire", "entretien panneau solaire", "nettoyage panneau",
                 "panne installation solaire", "controle installation solaire"],
        "reponse": (
            "La maintenance peut inclure l'inspection visuelle des modules et supports, "
            "la recherche de cables endommages, le controle des alarmes et le suivi de la production. "
            "Avant une intervention, applique les procedures de securite : un module eclaire "
            "peut produire une tension dangereuse. Les interventions electriques doivent etre "
            "effectuees par une personne competente avec le materiel adapte."
        )
    },
    {
        "titre": "Securite d'une installation solaire",
        "cles": ["securite solaire", "danger panneau solaire", "protection solaire",
                 "court circuit solaire", "cable photovoltaique"],
        "reponse": (
            "Une installation photovoltaique doit respecter les regles applicables et les "
            "instructions du fabricant. Verifie la polarite, les tensions maximales, les cables, "
            "connecteurs, protections et mise a la terre requise. Les panneaux peuvent rester "
            "sous tension lorsqu'ils sont eclaires. Ne manipule pas de conducteurs exposes sans "
            "competence, procedure et equipement adaptes."
        )
    },
    {
        "titre": "Technologies de panneaux",
        "cles": ["monocristallin", "polycristallin", "couche mince",
                 "technologie panneau solaire"],
        "reponse": (
            "Il existe plusieurs technologies photovoltaiques, notamment le silicium cristallin "
            "et certaines technologies a couches minces. Pour comparer des modules, examine les "
            "fiches techniques, puissance, rendement, dimensions, garanties et conditions d'utilisation."
        )
    },
    {
        "titre": "Recyclage des equipements solaires",
        "cles": ["recyclage panneau", "dechet solaire", "environnement solaire",
                 "fin de vie panneau"],
        "reponse": (
            "Les modules, batteries et composants electriques doivent etre geres correctement "
            "en fin de vie. Les filieres de collecte et de recyclage dependent du pays et des "
            "structures disponibles. Evite l'abandon des equipements dans la nature ; les batteries "
            "exigent une gestion adaptee a leur technologie."
        )
    },
]


# ---------------- CONNAISSANCES GÉNÉRALES (énergie, code, culture) ----------------
# Fiches hors ligne, au même format que les fiches photovoltaïques.
CONNAISSANCES_GENERALES = [
    {"titre": "energie renouvelable", "cles": ["energie renouvelable", "energies renouvelables", "renouvelable", "renouvelables"], "reponse": "Une énergie renouvelable vient d'une source qui se reconstitue à l'échelle humaine : soleil, vent, eau (hydraulique), biomasse, chaleur de la terre (géothermie), mers. Les énergies fossiles (pétrole, gaz, charbon) s'épuisent. Le nucléaire n'émet pas de CO2 en fonctionnement mais n'est pas renouvelable (uranium). Limite du solaire et de l'éolien : ils varient avec la météo, d'où le besoin de stockage et d'un réseau."},
    {"titre": "produire du courant", "cles": ["produire du courant", "produire de l electricite", "production d electricite", "production electrique", "comment produire", "produit le courant"], "reponse": "Pour produire du courant, on convertit une énergie en électricité. Le principe le plus courant est l'induction (Faraday) : un aimant qui tourne près d'une bobine crée une tension. Une source d'énergie (vapeur, eau, vent, moteur diesel) fait tourner une turbine ou un moteur qui entraîne un alternateur. Autres voies : cellules photovoltaïques (lumière → courant continu), piles et batteries (réaction chimique), thermocouples (chaleur)."},
    {"titre": "alternateur", "cles": ["alternateur", "alternateurs", "generatrice", "dynamo"], "reponse": "Alternateur : un rotor (inducteur : électroaimant ou aimants) tourne dans un stator (bobinages induits) et produit du courant alternatif. Fréquence : f = p × n / 60 (p paires de pôles, n en tr/min). Avec 2 paires de pôles, 1500 tr/min donnent 50 Hz. La dynamo, elle, produit du courant continu."},
    {"titre": "chaine energetique", "cles": ["chaine energetique", "systeme energetique", "systemes energetiques", "reseau electrique", "transport d electricite", "haute tension"], "reponse": "Le système électrique : production (centrales) → élévation de tension (transformateurs) → transport en haute tension → postes d'abaissement → distribution en moyenne puis basse tension (230/400 V) → consommateurs. On élève la tension car, pour une même puissance, le courant diminue et les pertes en ligne P = R × I² aussi. La production doit égaler la consommation à chaque instant."},
    {"titre": "centrale electrique", "cles": ["centrale electrique", "centrales electriques", "types de centrales", "centrale electrique fonctionne"], "reponse": "Une centrale électrique convertit une énergie primaire en électricité. Principaux types : thermique à flamme (charbon, gaz, fioul), nucléaire, hydraulique, éolienne, solaire (photovoltaïque ou thermodynamique), biomasse/biogaz, géothermique, et groupes électrogènes diesel pour le secours ou les sites isolés. La plupart font tourner une turbine couplée à un alternateur (sauf le solaire photovoltaïque)."},
    {"titre": "centrale thermique", "cles": ["centrale thermique", "centrale a vapeur", "centrale a gaz", "cycle combine"], "reponse": "Centrale thermique : un combustible (charbon, gaz, fioul) chauffe de l'eau ; la vapeur sous pression fait tourner une turbine qui entraîne l'alternateur, puis elle est condensée et réutilisée. Rendement d'environ 35 à 45 %. Les centrales à gaz à cycle combiné (turbine à gaz + turbine à vapeur) atteignent environ 55 à 60 %. Elles émettent du CO2."},
    {"titre": "centrale hydroelectrique", "cles": ["centrale hydroelectrique", "centrale hydraulique", "barrage", "hydroelectricite", "energie hydraulique"], "reponse": "Centrale hydroélectrique : l'eau retenue par un barrage tombe d'une hauteur H et fait tourner une turbine (Pelton, Francis, Kaplan) couplée à un alternateur. Puissance : P(kW) ≈ 9,81 × Q × H × η (Q en m³/s, H en m, η ≈ 0,85 à 0,9). Exemple : Q = 10 m³/s, H = 20 m, η = 0,85 → P ≈ 1668 kW. Exemple régional : le barrage de Nangbéto, sur le Mono (Togo/Bénin)."},
    {"titre": "energie eolienne", "cles": ["energie eolienne", "eolienne", "eoliennes", "eolien"], "reponse": "Éolienne : le vent fait tourner les pales, qui entraînent une génératrice (souvent via un multiplicateur). Puissance du vent : P = ½ × ρ × A × v³ × Cp (ρ ≈ 1,2 kg/m³ pour l'air, A surface balayée, v vitesse du vent, Cp ≤ 0,593 : limite de Betz). Comme P dépend de v³, doubler la vitesse du vent multiplie la puissance par 8."},
    {"titre": "centrale nucleaire", "cles": ["centrale nucleaire", "nucleaire", "fission"], "reponse": "Centrale nucléaire : la fission de noyaux d'uranium dans un réacteur libère de la chaleur qui produit de la vapeur pour une turbine et un alternateur. Elle fournit beaucoup d'énergie sans émettre de CO2 en fonctionnement, mais produit des déchets radioactifs et exige des règles de sûreté très strictes."},
    {"titre": "groupe electrogene", "cles": ["groupe electrogene", "groupes electrogenes", "generateur diesel", "centrale diesel"], "reponse": "Groupe électrogène : un moteur thermique (diesel ou essence) entraîne un alternateur. Il sert de secours ou de source sur les sites isolés. Prévois une puissance (kVA) avec marge pour le démarrage des moteurs, entretiens huile et filtres, et ne le fais jamais tourner dans un local fermé (gaz d'échappement mortels). Il consomme du carburant et émet du CO2."},
    {"titre": "biomasse", "cles": ["biomasse", "biogaz", "methanisation", "biocarburant", "biocarburants", "culture energetique", "cultures energetiques"], "reponse": "La biomasse (bois, résidus agricoles, déchets) produit de l'énergie par combustion ou méthanisation (le biogaz, riche en méthane, alimente un moteur-générateur). Les cultures énergétiques (canne à sucre, maïs, manioc pour l'éthanol ; palmier à huile, jatropha pour le biodiesel) fournissent des biocarburants. Limite : elles peuvent concurrencer les cultures alimentaires et demander terres et eau."},
    {"titre": "agrivoltaique", "cles": ["agrivoltaique", "agrivoltaisme", "pompage solaire", "irrigation solaire"], "reponse": "Agrivoltaïsme : des panneaux solaires sont installés au-dessus ou entre des cultures sur la même parcelle ; l'ombre partielle peut protéger certaines plantes de la chaleur. Pompage solaire : des panneaux alimentent une pompe pour irriguer sans carburant ; on stocke souvent l'eau dans un réservoir plutôt que l'électricité dans des batteries."},
    {"titre": "geothermie", "cles": ["geothermie", "energie marine", "energies marines", "maremotrice", "houlomotrice"], "reponse": "Géothermie : la chaleur du sous-sol produit de la vapeur pour une turbine, ou chauffe directement des bâtiments. Énergies marines : marémotrice (marées), houlomotrice (vagues) et hydroliennes (courants). Elles sont peu répandues et très dépendantes du site."},
    {"titre": "rendement", "cles": ["rendement", "efficacite energetique"], "reponse": "Rendement η = puissance (ou énergie) utile / puissance (ou énergie) absorbée, toujours inférieur à 1. Exemple : un moteur absorbe 5 kW et fournit 4 kW utiles → η = 0,8 = 80 %. Le reste est perdu surtout en chaleur. Le rendement global d'une chaîne est le produit des rendements de chaque étape."},
    {"titre": "stockage d energie", "cles": ["stockage d energie", "stockage energie", "stockage de l energie", "hydrogene"], "reponse": "Stocker l'énergie compense les variations du solaire et de l'éolien : batteries (plomb, lithium), stations de transfert d'énergie par pompage (STEP : on remonte l'eau en période creuse, puis on la turbine), hydrogène, volants d'inertie, stockage thermique. Chaque solution a son coût, son rendement et sa durée de stockage."},
    {"titre": "mix energetique", "cles": ["mix energetique", "mix electrique", "energie primaire", "energie finale", "sources d energie"], "reponse": "Le mix énergétique est la répartition des sources utilisées par un pays pour produire son énergie (hydraulique, gaz, solaire, etc.). Énergie primaire : source brute (pétrole, vent, soleil). Énergie finale : celle livrée au consommateur (électricité, carburant). Énergie utile : le service obtenu (lumière, mouvement). À chaque étape, il y a des pertes."},
    {"titre": "electricite au benin", "cles": ["electricite au benin", "energie au benin", "sbee"], "reponse": "Au Bénin, la SBEE (Société Béninoise d'Énergie Électrique) assure la distribution de l'électricité. Une part importante de l'électricité consommée est importée des pays voisins, et le pays développe aussi le solaire et ses propres capacités de production. Pour des chiffres à jour, consulte les sites officiels (SBEE, ministère de l'énergie)."},
    {"titre": "unite d energie", "cles": ["unite d energie", "unites d energie", "joule", "kilowattheure", "difference puissance energie"], "reponse": "Puissance (watt, W) = rythme auquel l'énergie est produite ou consommée. Énergie = puissance × temps : joule (1 J = 1 W × 1 s) ou wattheure (1 kWh = 3 600 000 J). Exemple : une lampe de 100 W allumée 10 h consomme 1 kWh. Ne pas confondre kW (puissance) et kWh (énergie)."},
    {"titre": "apprendre le code", "cles": ["apprendre le code", "apprendre a programmer", "programmation", "algorithme", "c est quoi programmer", "apprendre a coder"], "reponse": "Programmer, c'est écrire des instructions précises qu'un ordinateur exécute. Un algorithme est la suite d'étapes qui résout un problème (comme une recette de cuisine). Méthode : comprendre le problème, écrire l'algorithme, le traduire dans un langage (Python, JavaScript…), tester, corriger. Conseil : commence par Python, écris de petits programmes et pratique chaque jour."},
    {"titre": "variable python", "cles": ["variable python", "variables en python", "types de donnees", "python variable", "variable en python"], "reponse": "En Python, une variable stocke une valeur : age = 25, nom = 'Edison', tension = 230.5. Types courants : int (entier), float (décimal), str (texte), bool (True/False), list, dict. print(nom) affiche la valeur ; input() lit ce que tape l'utilisateur ; int('5') convertit un texte en entier."},
    {"titre": "condition python", "cles": ["condition python", "boucle", "boucles", "if else", "boucle for", "boucle while"], "reponse": "Condition : if tension > 240: print('Trop haute') elif tension < 200: print('Trop basse') else: print('Normale'). Boucle for : for i in range(5): print(i) répète 5 fois. Boucle while : while courant > 0: ... tant que la condition est vraie. En Python, l'indentation (4 espaces) délimite les blocs."},
    {"titre": "fonction python", "cles": ["fonction python", "definir une fonction", "liste python", "dictionnaire python", "fonction en python"], "reponse": "Fonction : def puissance(u, i): return u * i ; puissance(230, 5) donne 1150. Liste : appareils = ['lampe', 'fer'] ; appareils.append('tv') ajoute un élément ; appareils[0] donne le premier. Dictionnaire : prix = {'fil': 1000, 'prise': 300} ; prix['fil'] donne 1000. Les fonctions évitent de répéter du code."},
    {"titre": "html", "cles": ["html", "css", "javascript", "page web", "site web", "creer un site"], "reponse": "Un site web combine HTML (structure : titres, paragraphes, boutons), CSS (apparence : couleurs, tailles, mise en page) et JavaScript (comportement : réagir aux clics, calculer). Exemple minimal : <h1>Bonjour</h1> <button onclick=\"alert('Salut')\">Clique</button>. Enregistre le texte dans un fichier .html et ouvre-le dans un navigateur pour le tester."},
    {"titre": "erreur de code", "cles": ["erreur de code", "bug", "debogage", "debugger", "deboguer", "corriger un code"], "reponse": "Déboguer : 1) lis le message d'erreur en entier, surtout la dernière ligne et le numéro de ligne ; 2) vérifie indentation, guillemets et deux-points ; 3) affiche des valeurs avec print() pour suivre le programme ; 4) isole la partie qui échoue ; 5) cherche le message d'erreur en ligne. Erreurs courantes : SyntaxError (écriture), NameError (variable inconnue), TypeError (mauvais type), IndentationError."},
    {"titre": "arduino", "cles": ["arduino", "microcontroleur", "raspberry"], "reponse": "Un microcontrôleur (Arduino, ESP32…) est un petit ordinateur qui lit des capteurs et commande des sorties (LED, relais, moteurs). Exemple Arduino : pinMode(13, OUTPUT); digitalWrite(13, HIGH); delay(1000); digitalWrite(13, LOW); delay(1000); fait clignoter une LED. Pour commander un appareil en 230 V, utilise un relais ou un module adapté, avec une isolation sûre."},
    {"titre": "salutation", "cles": ["salutation", "salutations", "comment saluer", "regles de salutation", "savoir saluer", "bien saluer"], "reponse": "Bien saluer : dis Bonjour (jusqu'en fin d'après-midi) ou Bonsoir (le soir), avec le sourire et en regardant la personne. Salue en premier en entrant quelque part, et salue d'abord les aînés par respect. Poignée de main ferme mais douce ; n'impose pas le contact si l'autre ne le propose pas. Dans beaucoup de régions d'Afrique de l'Ouest, prendre le temps de demander des nouvelles (famille, travail) est un signe de respect. Avec les inconnus, dis Madame ou Monsieur."},
    {"titre": "politesse", "cles": ["politesse", "savoir vivre", "bonnes manieres", "regles de politesse", "etre poli"], "reponse": "Règles de politesse : dire s'il vous plaît, merci, pardon et excusez-moi ; ne pas couper la parole ; écouter avec attention ; être ponctuel et prévenir en cas de retard ; ne pas crier ni se moquer ; remercier après un service ; céder sa place aux personnes âgées, aux femmes enceintes et aux personnes fragiles ; garder son téléphone discret en réunion, à table ou au culte."},
    {"titre": "tutoiement", "cles": ["tutoiement", "vouvoiement", "tutoyer", "vouvoyer"], "reponse": "On vouvoie (vous) les inconnus, les personnes plus âgées, les supérieurs et dans les situations formelles (entretien, administration) ; on tutoie (tu) la famille, les amis et les enfants. En cas de doute, mieux vaut vouvoyer et attendre que l'autre propose de se tutoyer."},
    {"titre": "politesse au travail", "cles": ["politesse au travail", "savoir vivre au travail", "entretien d embauche", "bonne conduite", "ecrire un mail", "lettre formelle"], "reponse": "Au travail ou en entretien : arrive en avance, tenue propre et adaptée, salue chacun, regarde ton interlocuteur, parle calmement, écoute sans couper, remercie à la fin. Pour un e-mail ou une lettre : objet clair, formule d'appel (Madame, Monsieur), texte court et poli, formule de politesse finale, signature."},
    {"titre": "culture generale", "cles": ["culture generale"], "reponse": "La culture générale est l'ensemble des connaissances sur le monde : histoire, géographie, sciences, arts, langues, société. Pour la développer : lire, suivre l'actualité, poser des questions, apprendre un fait nouveau chaque jour et en parler. Propose-moi un sujet (le Bénin, les continents, l'énergie…) et je t'en dis plus."},
    {"titre": "histoire du benin", "cles": ["histoire du benin", "dahomey", "independance du benin", "culture du benin", "vodun", "ouidah"], "reponse": "Le Bénin (ancien Dahomey) a proclamé son indépendance le 1er août 1960. Capitale officielle : Porto-Novo ; Cotonou est la capitale économique. Langue officielle : le français ; de nombreuses langues nationales sont parlées (fon, yoruba, bariba, dendi, etc.). Le pays est connu pour ses royaumes historiques (Abomey), pour le vodun (religion traditionnelle née dans la région) et pour la ville de Ouidah."},
    {"titre": "continents", "cles": ["continents", "oceans", "geographie du monde", "systeme solaire"], "reponse": "Il y a 5 ou 6 continents selon les conventions : Afrique, Amérique, Asie, Europe, Océanie (et l'Antarctique). Les cinq océans : Pacifique, Atlantique, Indien, Arctique et Austral. L'Afrique compte 54 États membres de l'ONU. La Terre tourne sur elle-même en 24 h et autour du Soleil en environ 365 jours."},
]


# Fiches reprises de la version HTML (mots entiers pour éviter les faux positifs).
CONNAISSANCES_GENERALES += [
    {"titre": "electrotechnique", "cles": ["electrotechnique"], "reponse": "L'électrotechnique étudie la production, le transport, la transformation et l'utilisation de l'énergie électrique (courants forts) : machines, installations, protections, automatismes et énergies renouvelables.", "mot_entier": True},
    {"titre": "electronique", "cles": ["electronique"], "reponse": "L'électronique étudie et utilise les composants et circuits qui contrôlent les signaux et le courant électrique : diodes, transistors, résistances, condensateurs, circuits intégrés, alimentations et cartes électroniques. Elle est utilisée dans les téléphones, téléviseurs, ordinateurs, automatismes et appareils de mesure.", "mot_entier": True},
    {"titre": "electronique analogique", "cles": ["electronique analogique"], "reponse": "L'électronique analogique traite des signaux continus qui varient dans le temps. Elle utilise notamment résistances, condensateurs, diodes, transistors et amplificateurs opérationnels.", "mot_entier": True},
    {"titre": "electronique numerique", "cles": ["electronique numerique"], "reponse": "L'électronique numérique traite des informations sous forme de valeurs discrètes, souvent 0 et 1. Elle est utilisée dans les microcontrôleurs, ordinateurs, automates et systèmes numériques.", "mot_entier": True},
    {"titre": "physique", "cles": ["physique", "la physique"], "reponse": "La physique est une science qui étudie la matière, l'énergie, le mouvement, les forces et les lois qui décrivent la nature.", "mot_entier": True},
    {"titre": "chimie", "cles": ["chimie", "la chimie"], "reponse": "La chimie étudie la composition, les propriétés et les transformations de la matière.", "mot_entier": True},
    {"titre": "mathematique", "cles": ["mathematique", "mathematiques", "maths"], "reponse": "Les mathématiques étudient notamment les nombres, les formes, les structures, les relations et les raisonnements logiques.", "mot_entier": True},
    {"titre": "electricite", "cles": ["electricite", "l electricite"], "reponse": "L'électricité est liée à la présence et au déplacement de charges électriques. Elle permet d'alimenter les appareils, l'éclairage, les moteurs et les machines.", "mot_entier": True},
    {"titre": "informatique", "cles": ["informatique"], "reponse": "L'informatique concerne le traitement automatique de l'information à l'aide d'ordinateurs et de programmes.", "mot_entier": True},
    {"titre": "tension electrique", "cles": ["tension electrique", "la tension", "volt", "volts"], "reponse": "La tension U est la « pression » électrique entre deux points. Elle se mesure en volts (V), avec un voltmètre branché en parallèle.", "mot_entier": True},
    {"titre": "courant electrique", "cles": ["courant electrique", "intensite du courant", "ampere", "amperes"], "reponse": "Le courant I est la quantité de charges qui circule par seconde. Il se mesure en ampères (A), avec un ampèremètre en série ou une pince ampèremétrique.", "mot_entier": True},
    {"titre": "resistance electrique", "cles": ["resistance electrique", "ohm resistance", "les resistances"], "reponse": "La résistance R s'oppose au passage du courant. Elle se mesure en ohms (Ω), toujours hors tension.", "mot_entier": True},
    {"titre": "puissance electrique", "cles": ["puissance electrique", "la puissance", "watt", "watts"], "reponse": "Puissance : P = U × I en continu. En monophasé P = U × I × cos φ ; en triphasé P = √3 × U × I × cos φ. Unité : le watt (W).", "mot_entier": True},
    {"titre": "triphase", "cles": ["triphase", "monophase", "trois phases"], "reponse": "Monophasé : 230 V (phase + neutre). Triphasé : trois phases décalées de 120°, 400 V entre phases, adapté aux moteurs et aux fortes puissances.", "mot_entier": True},
    {"titre": "differentiel", "cles": ["differentiel", "interrupteur differentiel"], "reponse": "Le différentiel détecte une fuite de courant vers la terre. 30 mA protège les personnes ; on le teste avec le bouton T.", "mot_entier": True},
    {"titre": "mise a la terre", "cles": ["mise a la terre", "prise de terre", "piquet de terre"], "reponse": "La mise à la terre écoule les courants de défaut vers le sol pour protéger les personnes. Fil vert-jaune, piquet de terre, résistance de terre la plus faible possible.", "mot_entier": True},
    {"titre": "contacteur", "cles": ["contacteur", "contacteurs"], "reponse": "Le contacteur est un interrupteur commandé par une bobine : contacts principaux pour la puissance, contacts auxiliaires pour la commande.", "mot_entier": True},
    {"titre": "relais thermique", "cles": ["relais thermique"], "reponse": "Le relais thermique protège un moteur contre les surcharges. On le règle sur le courant nominal de la plaque du moteur.", "mot_entier": True},
    {"titre": "moteur asynchrone", "cles": ["moteur asynchrone", "moteur triphase"], "reponse": "Le moteur asynchrone triphasé a un stator qui crée un champ tournant et un rotor en cage d'écureuil. Vitesse de synchronisme : n = 60·f / p (1500 tr/min à 50 Hz avec 2 paires de pôles).", "mot_entier": True},
    {"titre": "court circuit", "cles": ["court circuit", "surcharge", "court circuits"], "reponse": "Court-circuit : contact direct entre conducteurs, courant très élevé, coupé par disjoncteur ou fusible. Surcharge : courant trop fort pendant un certain temps, qui chauffe les câbles.", "mot_entier": True},
    {"titre": "impedance", "cles": ["impedance", "circuit rlc"], "reponse": "Impédance complexe : ZR = R, ZL = jLω, ZC = 1/(jCω), avec ω = 2πf. RLC série : Z = R + j(Lω − 1/(Cω)).", "mot_entier": True},
    {"titre": "nombre complexe", "cles": ["nombre complexe", "nombres complexes"], "reponse": "Un nombre complexe s'écrit Z = a + jb (j² = −1). Module r = √(a²+b²), argument θ = arctan(b/a). On s'en sert en alternatif pour traiter ensemble amplitude et déphasage.", "mot_entier": True},
    {"titre": "cos phi", "cles": ["cos phi", "facteur de puissance"], "reponse": "cos φ = P / S : rapport entre puissance active et apparente. Un moteur a souvent cos φ ≈ 0,8 ; on l'améliore avec des condensateurs.", "mot_entier": True},
    {"titre": "consignation", "cles": ["consignation", "securite electrique", "vat"], "reponse": "Avant d'intervenir : séparer, condamner, vérifier l'absence de tension (VAT), puis mettre à la terre et en court-circuit si nécessaire.", "mot_entier": True},
    {"titre": "variateur", "cles": ["variateur", "variateur de vitesse"], "reponse": "Le variateur de vitesse change la fréquence et la tension pour piloter la vitesse d'un moteur asynchrone.", "mot_entier": True},
    {"titre": "videosurveillance", "cles": ["videosurveillance", "camera de surveillance", "cameras"], "reponse": "Caméras analogiques : coaxial + DVR. Caméras IP : câble réseau (100 m max) + NVR, avec PoE possible. Prévoir alimentation, stockage et protection contre l'humidité.", "mot_entier": True},
    {"titre": "intelligence artificielle", "cles": ["intelligence artificielle"], "reponse": "L'intelligence artificielle (IA) regroupe des méthodes informatiques permettant à un système d'effectuer des tâches comme comprendre du texte, reconnaître des images, traduire ou produire des réponses. Ses résultats doivent être vérifiés.", "mot_entier": True},
]


# Fiches métier : câbles, moteurs, solaire, mesure, sécurité, histoire d'Edison.
CONNAISSANCES_GENERALES += [
    {"titre": "section de cable", "cles": ["section de cable", "section d un cable", "choisir un cable", "choisir la section", "calibre du disjoncteur", "chute de tension"], "reponse": "Choisir un câble : 1) calcule le courant : I = P / (U × cos φ) en monophasé, I = P / (√3 × U × cos φ) en triphasé ; 2) prends une section dont le courant admissible dépasse I. Calibres maximum usuels du disjoncteur selon la NF C 15-100 (cuivre) : 1,5 mm² → 16 A ; 2,5 mm² → 20 A ; 4 mm² → 25 A ; 6 mm² → 32 A ; 10 mm² → 40 A. 3) Vérifie la chute de tension (≤ 3 % éclairage, ≤ 5 % autres usages) : ΔU = 2 × 0,023 × L × I / S en monophasé (L en m, S en mm²). Exemple : 20 m, 16 A, 2,5 mm² → ΔU ≈ 5,9 V (2,6 %). Le disjoncteur doit toujours protéger le câble. Vérifie la norme appliquée chez toi."},
    {"titre": "demarrage direct", "cles": ["demarrage direct", "demarrage direct d un moteur", "demarrer un moteur"], "reponse": "Démarrage direct d'un moteur triphasé : un contacteur KM relie le moteur au réseau. Commande : bouton arrêt S1 (contact NF) en série, bouton marche S2 (contact NO) avec le contact d'automaintien de KM en parallèle. Protection : disjoncteur magnétique ou fusibles (court-circuit) + relais thermique réglé sur le courant nominal (surcharge). Simple, mais l'appel de courant est de 5 à 8 fois le courant nominal : réservé aux petits et moyens moteurs."},
    {"titre": "etoile triangle", "cles": ["etoile triangle", "demarrage etoile triangle", "etoile-triangle"], "reponse": "Démarrage étoile-triangle : au départ le moteur est couplé en étoile (chaque enroulement reçoit U/√3), ce qui divise par 3 le courant et le couple d'appel ; après quelques secondes (temporisateur) on passe en triangle. Matériel : 3 contacteurs (réseau KM1, étoile KM2, triangle KM3), un temporisateur, un relais thermique. Condition : la plaque doit indiquer 400 V en triangle (ex. 230/400 V) sur un réseau 400 V. KM2 et KM3 ne doivent jamais être fermés ensemble (verrouillage), sinon c'est un court-circuit."},
    {"titre": "plaque signaletique", "cles": ["plaque signaletique", "plaque du moteur", "lire la plaque"], "reponse": "Plaque d'un moteur : U (ex. 230/400 V : tension du couplage triangle/étoile), I (courant nominal, ex. 5,2/3 A : le plus grand courant va avec la plus petite tension), P (puissance utile en kW), cos φ, n (vitesse en tr/min), f (50 Hz), IP (protection poussière/eau), classe d'isolation. Règle le relais thermique sur le courant nominal correspondant à ton couplage."},
    {"titre": "schema electrique", "cles": ["schema electrique", "lire un schema", "symboles electriques", "schema de puissance", "schema de commande"], "reponse": "Schéma de puissance (gros traits : alimentation, contacteur, thermique, moteur) et schéma de commande (boutons, bobine, auxiliaires). Repères courants : QF disjoncteur, KM contacteur, FR relais thermique, S bouton, H voyant, M moteur, L phase, N neutre, PE terre. Contact NO (ouvert au repos) : 13-14 ; NC (fermé au repos) : 11-12 ou 21-22 ; bobine : A1-A2 ; pôles de puissance : 1-2, 3-4, 5-6. Lis le schéma en suivant le courant de la source vers la charge."},
    {"titre": "depannage", "cles": ["depannage", "depanner", "diagnostic de panne", "trouver une panne", "panne electrique", "methode de depannage"], "reponse": "Dépanner méthodiquement : 1) écoute l'utilisateur et observe le symptôme ; 2) vérifie les causes simples (alimentation, disjoncteur, fusible, arrêt d'urgence) ; 3) consigne et vérifie l'absence de tension avant tout travail ; 4) remonte du récepteur vers la source, ou coupe le circuit en deux moitiés ; 5) mesure (tension, continuité, isolement) et compare à ce qui est attendu ; 6) remplace le composant défaillant et cherche la cause ; 7) teste, remets en service, note l'intervention. Ne court-circuite jamais une protection pour tester."},
    {"titre": "moteur ne demarre pas", "cles": ["moteur ne demarre pas", "moteur ne tourne pas", "moteur qui ne demarre pas", "moteur ronfle", "moteur en panne"], "reponse": "Moteur qui ne démarre pas : 1) tension présente sur les 3 phases (une phase absente = ronflement, risque de brûler le moteur) ; 2) protections : disjoncteur, relais thermique déclenché ; 3) contacteur : la bobine reçoit-elle la tension ? les contacts ferment-ils ? 4) commande : boutons, arrêt d'urgence, fins de course ; 5) moteur : continuité des enroulements, isolement au mégohmmètre, arbre bloqué mécaniquement ; 6) en monophasé : condensateur de démarrage. Mesures de résistance toujours hors tension."},
    {"titre": "dimensionner une installation solaire", "cles": ["dimensionner une installation solaire", "dimensionnement solaire", "calculer une installation solaire", "combien de panneaux", "installation solaire complete", "dimensionnement photovoltaique"], "reponse": "Dimensionner un système solaire autonome : 1) liste les appareils : P (W) × heures par jour = Wh/jour ; additionne → Ec. 2) Panneaux : Pc = Ec / (Hs × k) ; Hs = heures de plein soleil (environ 4 à 5,5 h/jour sous nos latitudes, à vérifier), k ≈ 0,6 à 0,75 (pertes). 3) Batterie : C(Ah) = Ec × jours d'autonomie / (U × DoD × η) ; DoD ≈ 0,5 plomb, 0,8 lithium. 4) Régulateur : courant ≥ Pc / U batterie, +25 %. 5) Onduleur : puissance ≥ appareils simultanés + marge de démarrage (moteurs, frigo ×3 à 5). Exemple : 600 Wh/j, Hs = 5, k = 0,7 → Pc ≈ 171 W → 2 panneaux de 100 Wc ; batterie 12 V, 1 jour, DoD 0,5, η 0,85 → ≈ 118 Ah → 120 Ah."},
    {"titre": "regulateur de charge", "cles": ["regulateur de charge", "regulateur solaire", "mppt", "pwm"], "reponse": "Régulateur de charge : protège la batterie contre la surcharge et la décharge profonde. PWM : simple et économique, la tension des panneaux doit correspondre à celle de la batterie. MPPT : cherche le point de puissance maximale et transforme l'excédent de tension en courant (+10 à 30 % de rendement), adapté aux grands champs. Choisis un courant ≥ Isc totale × 1,25 et une tension d'entrée maximale au-dessus de la tension à vide (Voc) des panneaux en série, surtout par temps froid."},
    {"titre": "installer la videosurveillance", "cles": ["installer la videosurveillance", "installation de camera", "installer une camera", "installer des cameras", "stockage videosurveillance"], "reponse": "Installer la vidéosurveillance : 1) repère les zones (entrées, accès, angles morts) ; 2) type : analogique (coaxial + DVR) ou IP (câble réseau jusqu'à 100 m + NVR, PoE possible) ; 3) alimentation : 12 V par caméra avec un bloc adapté (courant total + 20 %) ou PoE ; 4) câbles en gaine, loin des câbles de puissance, connecteurs étanches ; 5) disque dur : environ 10 à 40 Go par jour et par caméra selon la résolution et les réglages ; 6) pose en hauteur (2,5 à 3 m), à l'abri de la pluie et du soleil direct ; 7) change les mots de passe par défaut."},
    {"titre": "antenne parabolique", "cles": ["antenne parabolique", "installer une antenne", "installation d antenne", "pointer une parabole", "decodeur"], "reponse": "Installer une antenne parabolique (ex. Canal+) : choisis un emplacement dégagé en direction du satellite, fixe solidement le mât et la parabole, monte le LNB, tire un câble coaxial (connecteurs F bien serrés et protégés de l'eau) jusqu'au décodeur. Pointe en réglant azimut, élévation et polarisation avec un pointeur de satellite ou le menu de signal du décodeur ; serre quand niveau et qualité sont maximaux. Prévois mise à la terre et parafoudre. Les angles exacts dépendent du satellite et du pays : suis les consignes de l'opérateur."},
    {"titre": "multimetre", "cles": ["multimetre", "multimetres"], "reponse": "Multimètre : tension (V alternatif ou continu) en parallèle ; courant (A) en série, cordon sur la bonne borne (10 A pour les gros courants) ; résistance et continuité (bip) HORS TENSION ; commence par le plus grand calibre en cas de doute. Erreur dangereuse : mesurer une tension avec un cordon sur la borne ampère = court-circuit. Teste ton appareil sur une source connue avant et après une vérification d'absence de tension."},
    {"titre": "pince amperemetrique", "cles": ["pince amperemetrique", "pince ampermetrique", "mesurer un courant"], "reponse": "Pince ampèremétrique : mesure le courant sans ouvrir le circuit, en entourant UN SEUL conducteur (une phase, pas le câble entier : les champs s'annulent et l'on lit 0). Utile pour régler le thermique d'un moteur, voir le déséquilibre entre phases, vérifier la consommation. Choisis AC ou DC selon le courant."},
    {"titre": "megohmmetre", "cles": ["megohmmetre", "mesurer l isolement", "isolement electrique"], "reponse": "Mégohmmètre : mesure l'isolement (en MΩ) en appliquant une tension élevée (souvent 500 V ou 1000 V), circuit HORS TENSION et appareils électroniques débranchés. Repère usuel en basse tension : au moins 0,5 à 1 MΩ selon la norme. Mesure entre phases et entre chaque phase et la terre. Décharge le circuit après la mesure."},
    {"titre": "cinq regles", "cles": ["cinq regles", "5 regles", "regles de securite electrique", "consignation electrique", "habilitation"], "reponse": "Les 5 règles avant d'intervenir : 1) séparer le circuit de toute source ; 2) condamner (cadenas, étiquette) ; 3) identifier le circuit ; 4) vérifier l'absence de tension (VAT) avec un appareil adapté ; 5) mettre à la terre et en court-circuit si nécessaire. Ajoute : gants isolants, lunettes, chaussures isolantes, outils isolés ; ne travaille jamais seul sur un risque élevé ; ne suppose jamais qu'un circuit est coupé sans le vérifier."},
    {"titre": "erreurs frequentes", "cles": ["erreurs frequentes", "accident electrique", "danger electrique", "electrisation", "choc electrique"], "reponse": "Erreurs qui causent des accidents : travailler sous tension pour aller vite ; se fier à un interrupteur sans vérifier ; oublier de remettre la terre ; mauvais serrage des connexions (échauffement, incendie) ; câble sous-dimensionné ; rallonges surchargées ; mains mouillées ; disjoncteur trop gros pour le câble ; neutre coupé ou inversé. Un courant de l'ordre de 30 mA traversant le corps est dangereux, d'où le différentiel 30 mA. En cas de choc, coupe d'abord l'alimentation avant de toucher la victime, et appelle les secours."},
    {"titre": "couleur des fils", "cles": ["couleur des fils", "couleurs des fils", "couleur du fil", "code couleur"], "reponse": "Couleurs usuelles (norme européenne/CEI) : terre = vert-jaune (jamais autre chose) ; neutre = bleu clair ; phases = marron, noir, gris (le rouge est aussi toléré). En continu (solaire) : positif rouge, négatif noir. Respecte les couleurs déjà présentes dans l'installation et vérifie la norme appliquée chez toi."},
    {"titre": "normes electriques", "cles": ["normes electriques", "norme electrique", "cei 60364"], "reponse": "Une norme fixe les règles de conception et de sécurité d'une installation. En basse tension, beaucoup de pays francophones s'appuient sur la NF C 15-100 (France) et la CEI 60364 (internationale). Elles imposent par exemple le différentiel 30 mA, la mise à la terre, des sections minimales et des protections. Vérifie les règles locales (au Bénin, renseigne-toi auprès de la SBEE) et consulte toujours le texte officiel à jour."},
    {"titre": "qui est thomas edison", "cles": ["qui est thomas edison", "thomas edison", "thomas alva edison"], "reponse": "Thomas Alva Edison (1847-1931) était un inventeur et entrepreneur américain. Il est connu pour avoir mis au point une ampoule électrique à incandescence pratique, pour le phonographe et pour plus de mille brevets. Il a créé à Menlo Park un laboratoire de recherche organisé, avec une équipe, et a persévéré à travers de très nombreux essais. C'est l'idole de mon créateur."},
    {"titre": "ton projet", "cles": ["ton projet", "ton objectif", "tes objectifs", "ton but", "ta mission", "ton reve", "pourquoi tu existes", "ton histoire", "quel est ton projet", "quel est ton objectif"], "reponse": "Je suis Edison IA, un assistant francophone créé par Edison Ahodede, électrotechnicien. Nos objectifs : 1) aider à apprendre et à résoudre des problèmes d'électricité, d'électrotechnique et de solaire ; 2) enseigner aussi les énergies renouvelables, les centrales, le code et la culture générale ; 3) respecter les bonnes manières (salutations, politesse) ; 4) retenir ce qu'on m'apprend ; 5) devenir une vraie assistante IA qui comprend le sens des questions, calcule et, plus tard, écoute et parle. Mon créateur rêve de bâtir quelque chose de plus grand : je dois rester fidèle à ce but."},
    {"titre": "collaborer", "cles": ["collaborer", "collaboration", "soutenir edison", "devenir partenaire", "aider edison", "contacter ton createur"], "reponse": "Le projet Edison est ouvert aux échanges : tu peux tester l'assistant, donner ton avis ou proposer des idées. Pour en parler avec son créateur, Edison Ahodede, électrotechnicien, contacte-le directement."},
    {"titre": "famille ahodede", "cles": ["famille ahodede", "la famille ahodede", "les ahodede", "histoire ahodede", "histoire de la famille ahodede", "ahodede abomey", "connais tu la famille ahodede"], "reponse": "Oui, je connais la famille AHODEDE. Elle est établie à Abomey. Ses ancêtres y ont été amenés par le roi Guezo, dont ils étaient des fidèles et les prêtres de Fâ. Aujourd'hui, c'est l'une des plus grandes familles d'Abomey."},
    {"titre": "roi guezo", "cles": ["roi guezo", "qui est guezo", "guezo", "roi ghezo", "ghezo", "roi gezo", "gezo"], "reponse": "Guezo (écrit aussi Ghézo ou Gezo) est le neuvième roi d'Abomey (royaume du Dahomey, aujourd'hui Bénin). Il a régné de 1818 à 1858, une période considérée comme l'apogée du Dahomey. Il était le fils du roi Agonglo ; son fils Glélé lui a succédé, puis Béhanzin, fils de Glélé. Les ancêtres de la famille AHODEDE d'Abomey étaient ses fidèles et ses prêtres de Fâ."},
    {"titre": "rodriguez paul", "cles": ["rodriguez paul", "paul rodriguez", "qui est rodriguez paul", "qui est paul rodriguez"], "reponse": "Rodriguez Paul est une personne qui a fait le BTP (bâtiment et travaux publics) et le génie civil. C'est quelqu'un qui fait un excellent travail."},
]


def chercher_connaissance_photovoltaique(texte):
    """Retourne une fiche photovoltaique pertinente, sans Internet."""
    t = mots_vides(texte)
    if not t:
        return None

    meilleur_score = 0
    meilleure_fiche = None

    for fiche in CONNAISSANCES_PHOTOVOLTAIQUE + CONNAISSANCES_GENERALES:
        score = 0
        for cle in fiche["cles"]:
            cle_norm = mots_vides(cle)
            if cle_norm and ((" " + cle_norm + " ") in (" " + t + " ") if fiche.get("mot_entier") else cle_norm in t):
                # Les expressions longues et precises ont plus de poids.
                score = max(score, 2 + len(cle_norm.split()))
        if score > meilleur_score:
            meilleur_score = score
            meilleure_fiche = fiche

    if meilleure_fiche and meilleur_score >= 3:
        return meilleure_fiche["reponse"]
    return None


def chercher_connaissance(texte):
    # La base solaire locale est consultée en premier, meme sans Internet.
    solaire = chercher_connaissance_photovoltaique(texte)
    if solaire:
        return solaire

    t = normaliser(texte)

    # Recherche des mots-clés les plus précis d'abord.
    for cle, valeur in CONNAISSANCES.items():
        mots = cle.split()
        if all(re.search(r"\b" + re.escape(mot) + r"\b", t) for mot in mots):
            return valeur

    # Recherche dans la mémoire personnalisée
    for cle, valeur in memoire["connaissances"].items():
        if re.search(r"\b" + re.escape(cle) + r"\b", t):
            return valeur

    return None


# ---------------- CALCULS ÉLECTROTECHNIQUES ----------------

UNIT_ALIASES = {
    # tension
    "v": ("V", 1.0), "volt": ("V", 1.0), "volts": ("V", 1.0),
    "kv": ("V", 1000.0), "kilovolt": ("V", 1000.0), "kilovolts": ("V", 1000.0),
    "mv": ("V", 0.001), "millivolt": ("V", 0.001), "millivolts": ("V", 0.001),
    # courant
    "a": ("A", 1.0), "amp": ("A", 1.0), "ampere": ("A", 1.0), "amperes": ("A", 1.0),
    "ma": ("A", 0.001), "milliampere": ("A", 0.001), "milliamperes": ("A", 0.001),
    # résistance
    "ohm": ("Ω", 1.0), "ohms": ("Ω", 1.0), "ω": ("Ω", 1.0), "Ω": ("Ω", 1.0),
    "kohm": ("Ω", 1000.0), "kω": ("Ω", 1000.0), "kΩ": ("Ω", 1000.0),
    # puissance
    "w": ("W", 1.0), "watt": ("W", 1.0), "watts": ("W", 1.0),
    "kw": ("W", 1000.0), "kilowatt": ("W", 1000.0), "kilowatts": ("W", 1000.0),
    # énergie
    "wh": ("Wh", 1.0), "kwh": ("Wh", 1000.0),
    # temps
    "s": ("s", 1.0), "sec": ("s", 1.0), "seconde": ("s", 1.0), "secondes": ("s", 1.0),
    "min": ("s", 60.0), "minute": ("s", 60.0), "minutes": ("s", 60.0),
    "h": ("h", 1.0), "heure": ("h", 1.0), "heures": ("h", 1.0),
    # longueur / section pour câble
    "m": ("m", 1.0), "metre": ("m", 1.0), "metres": ("m", 1.0), "mètre": ("m", 1.0), "mètres": ("m", 1.0),
    "mm2": ("mm2", 1.0), "mm²": ("mm2", 1.0),
}


def _nombre_texte(x):
    return float(str(x).replace(",", "."))


def extraire_valeur_unite(texte, unite_cible=None):
    """Extrait une valeur suivie d'une unité. Retourne (valeur_normalisée, unité) ou None."""
    t = sans_accents(texte.lower()).replace("²", "2")
    pattern = r"(?<![a-zA-Z0-9])([-+]?\d+(?:[.,]\d+)?)\s*(kv|mv|kohm|kω|kΩ|kw|kwh|ma|mm2|mm²|wh|w|v|a|ohm|ω|Ω|h|min|s|m|ampere?s?|volt?s?|watt?s?|heure?s?|minute?s?|seconde?s?)\b"
    matches = re.findall(pattern, t, flags=re.I)
    for nombre, unite in matches:
        cle = unite.lower()
        if cle not in UNIT_ALIASES:
            continue
        unite_norm, facteur = UNIT_ALIASES[cle]
        valeur = _nombre_texte(nombre) * facteur
        if unite_cible is None or unite_norm == unite_cible:
            return valeur, unite_norm
    return None


def extraire_toutes_valeurs(texte):
    """Extrait les couples valeur/unité pour produire des messages d'erreur précis."""
    t = sans_accents(texte.lower()).replace("²", "2")
    pattern = r"(?<![a-zA-Z0-9])([-+]?\d+(?:[.,]\d+)?)\s*(kv|mv|kohm|kω|kΩ|kw|kwh|ma|mm2|wh|w|v|a|ohm|ω|Ω|h|min|s|m|ampere?s?|volt?s?|watt?s?|heure?s?|minute?s?|seconde?s?)\b"
    result = []
    for nombre, unite in re.findall(pattern, t, flags=re.I):
        cle = unite.lower()
        if cle in UNIT_ALIASES:
            u, facteur = UNIT_ALIASES[cle]
            result.append((_nombre_texte(nombre) * facteur, u, nombre, unite))
    return result


def valeur_par_unite(texte, unite):
    vals = extraire_toutes_valeurs(texte)
    for valeur, u, _, _ in vals:
        if u == unite:
            return valeur
    return None


def contient_mot(t, mots):
    return any(re.search(r"\b" + re.escape(m) + r"\b", t) for m in mots)


def format_unite(valeur, unite):
    """Affichage pratique avec une unité adaptée."""
    if unite == "V":
        if abs(valeur) >= 1000:
            return f"{format_nombre(valeur / 1000)} kV"
        if 0 < abs(valeur) < 1:
            return f"{format_nombre(valeur * 1000)} mV"
        return f"{format_nombre(valeur)} V"
    if unite == "A":
        if abs(valeur) >= 1:
            return f"{format_nombre(valeur)} A"
        return f"{format_nombre(valeur * 1000)} mA"
    if unite == "Ω":
        if abs(valeur) >= 1000:
            return f"{format_nombre(valeur / 1000)} kΩ"
        return f"{format_nombre(valeur)} Ω"
    if unite == "W":
        if abs(valeur) >= 1000:
            return f"{format_nombre(valeur / 1000)} kW"
        return f"{format_nombre(valeur)} W"
    if unite == "Wh":
        if abs(valeur) >= 1000:
            return f"{format_nombre(valeur / 1000)} kWh"
        return f"{format_nombre(valeur)} Wh"
    if unite == "s":
        return f"{format_nombre(valeur)} s"
    if unite == "h":
        return f"{format_nombre(valeur)} h"
    return f"{format_nombre(valeur)} {unite}"


def calcul_electrique(question):
    """Calcul local ; si l'IA est active, elle prend le relais quand il manque des données."""
    r = _calcul_electrique_local(question)
    if r and ia_disponible():
        calcul_fait = ("Formule" in r or "positives" in r or "cos φ doit" in r)
        if not calcul_fait:
            return None
    return r


def _calcul_electrique_local(question):
    """Calculs U, I, R, P, E et chute de tension avec contrôle des unités."""
    t = mots_vides(question)

    # Ne s'active que si la question ressemble à un calcul électrique.
    sujets = ["puissance", "tension", "courant", "intensite", "intensite", "resistance", "energie", "chute de tension"]
    if not contient_un(t, sujets):
        return None

    vals = extraire_toutes_valeurs(question)
    if not vals:
        return (
            "Je peux faire ce calcul, mais il me manque les valeurs avec leurs unités.\n"
            "Exemples : « puissance avec 230 V et 5 A » ou « résistance avec 24 V et 2 A »."
        )

    # Refus clair des unités inconnues détectables comme nombre + texte.
    nombres = re.findall(r"[-+]?\d+(?:[.,]\d+)?\s*([a-zA-ZΩ²]+)", question)
    unites_connues = {k.lower() for k in UNIT_ALIASES}
    for u in nombres:
        if u.lower() not in unites_connues:
            return f"Unité « {u} » non reconnue. Utilise V, A, Ω, W, kW, Wh, kWh, h, min ou s."

    # Valeurs principales
    U = valeur_par_unite(question, "V")
    I = valeur_par_unite(question, "A")
    R = valeur_par_unite(question, "Ω")
    P = valeur_par_unite(question, "W")
    E = valeur_par_unite(question, "Wh")
    h = valeur_par_unite(question, "h")
    secondes = valeur_par_unite(question, "s")
    minutes = valeur_par_unite(question, "s")

    if any(x is not None and x < 0 for x in [U, I, R, P, E, h, secondes, minutes]):
        return "Les valeurs électriques doivent être positives ou nulles. Une tension, un courant, une résistance, une puissance ou une énergie négative n'est pas acceptée ici."

    # cos phi optionnel
    cosphi = None
    qcos = question.lower().replace(",", ".")
    mcos = re.search(r"cos(?:inus)?(?:\s*(?:phi|φ))?\s*(?:=|de|a)?\s*([-+]?\d+(?:\.\d+)?)", qcos)
    if mcos:
        cosphi = _nombre_texte(mcos.group(1))
        if not 0 < cosphi <= 1:
            return "Le cos φ doit être strictement supérieur à 0 et inférieur ou égal à 1. Exemple : cos φ = 0,8."

    # PUISSANCE
    if contient_mot(t, ["puissance"]):
        if U is not None and I is not None:
            Pcalc = U * I * (cosphi if cosphi is not None else 1.0)
            mode = "avec cos φ" if cosphi is not None else "en courant continu / charge résistive"
            return f"Puissance calculée : {format_unite(Pcalc, 'W')}\nFormule : P = U × I" + (" × cos φ" if cosphi is not None else "") + f"\n({mode})."
        if P is not None:
            return "Tu m'as donné une puissance, mais pour vérifier/calculer il me faut aussi une tension et un courant."
        return "Pour calculer la puissance, donne une tension en V et un courant en A. Exemple : « puissance avec 230 V et 5 A »."

    # CHUTE DE TENSION (avant « tension » pour éviter qu'elle soit capturée comme U = RI)
    if contient_un(t, ["chute de tension"]):
        if R is not None and I is not None:
            return f"Chute de tension : {format_unite(R * I, 'V')}\nFormule : ΔU = R × I."
        return "Pour calculer la chute de tension avec la méthode simple, donne la résistance du conducteur en Ω et le courant en A. Exemple : « chute de tension avec 0,8 Ω et 10 A »."

    # TENSION
    if contient_mot(t, ["tension"]):
        if R is not None and I is not None:
            return f"Tension calculée : {format_unite(R * I, 'V')}\nFormule : U = R × I."
        if P is not None and I is not None and I != 0:
            return f"Tension calculée : {format_unite(P / I, 'V')}\nFormule : U = P / I."
        return "Pour calculer la tension, donne soit R en Ω et I en A, soit P en W et I en A."

    # COURANT
    if contient_mot(t, ["courant", "intensite"]):
        if U is not None and R is not None and R != 0:
            return f"Courant calculé : {format_unite(U / R, 'A')}\nFormule : I = U / R."
        if P is not None and U is not None and U != 0:
            return f"Courant calculé : {format_unite(P / U, 'A')}\nFormule : I = P / U."
        return "Pour calculer le courant, donne soit U en V et R en Ω, soit P en W et U en V."

    # RESISTANCE
    if contient_mot(t, ["resistance"]):
        if U is not None and I is not None and I != 0:
            return f"Résistance calculée : {format_unite(U / I, 'Ω')}\nFormule : R = U / I."
        if P is not None and I is not None and I != 0:
            return f"Résistance calculée : {format_unite(P / (I * I), 'Ω')}\nFormule : R = P / I²."
        if P is not None and U is not None and P != 0:
            return f"Résistance calculée : {format_unite((U * U) / P, 'Ω')}\nFormule : R = U² / P."
        return "Pour calculer la résistance, donne U en V et I en A (ou P et I / P et U)."

    # ENERGIE
    if contient_mot(t, ["energie"]):
        # Si P est donné en W et durée en h -> Wh. Si durée en min/s -> conversion.
        duree_h = h
        if duree_h is None and secondes is not None:
            duree_h = secondes / 3600.0
        if duree_h is None:
            return "Pour calculer l'énergie, donne une puissance en W ou kW et une durée en h, min ou s. Exemple : « énergie de 2 kW pendant 3 h »."
        if P is None:
            return "Il me manque la puissance. Exemple : « énergie de 1500 W pendant 2 h »."
        return f"Énergie calculée : {format_unite(P * duree_h, 'Wh')}\nFormule : E = P × t."

    return None

# ---------------- COÛTS ----------------

def parser_ligne_article(ligne):
    """
    Formats acceptés :
    - fil 10m 1000
    - fil;10;1000
    - 1 prise 300
    """
    ligne = ligne.strip()

    m = re.match(r"^(.*?)[\s;]+(\d+(?:[.,]\d+)?)\s+(\d+(?:[.,]\d+)?)\s*[fF]?$", ligne)
    if not m:
        return None

    nom = m.group(1).strip(" ;:-")
    quantite = float(m.group(2).replace(",", "."))
    prix = float(m.group(3).replace(",", "."))

    if not nom or quantite <= 0 or prix < 0:
        return None

    return nom, quantite, prix


def calculer_liste_cout(lignes):
    total = 0
    details = []

    for ligne in lignes:
        article = parser_ligne_article(ligne)
        if article is None:
            continue

        nom, qte, prix = article
        montant = qte * prix
        total += montant
        details.append((nom, qte, prix, montant))

    return total, details


# ---------------- COMMANDES ----------------

AIDE = """
Commandes Edison V6

  aide
      Affiche cette aide.

  retiens que nom = valeur
      Exemple : retiens que métier = électrotechnicien

  mémoire
      Affiche les informations mémorisées.

  oublie nom
      Supprime une information.

  apprends : question = réponse
      Enseigne une connaissance à Edison. Exemple :
      apprends : c'est quoi un fusible = Un fusible protège un circuit en fondant.

  calc 25*4+10
      Effectue un calcul sécurisé.

  coût
      Lance le calcul de coût. Exemple de lignes :
      fil méplat 10 1000
      prise 2 300
      ampoule 3 1000
      puis : fin

  heure
      Affiche la date et l'heure du téléphone.

  quitter
      Ferme Edison.

Tu peux aussi poser directement une question d'électrotechnique.
"""


def afficher_memoire():
    infos = memoire["informations"]
    if not infos:
        return "Ma mémoire personnelle est vide."

    lignes = ["Voici ce que je retiens :"]
    for cle, valeur in infos.items():
        lignes.append(f"- {cle} : {valeur}")
    return "\n".join(lignes)


def commande_cout():
    print("\nEDISON — CALCUL DE COÛT")
    print("Format : article quantité prix_unitaire")
    print("Exemple : prise 2 300")
    print("Tape 'fin' pour terminer.\n")

    lignes = []
    while True:
        ligne = input("Article > ").strip()
        if normaliser(ligne) == "fin":
            break
        if ligne:
            lignes.append(ligne)

    total, details = calculer_liste_cout(lignes)

    if not details:
        return "Je n'ai pas reconnu les lignes. Exemple : prise 2 300"

    print("\nDÉTAIL")
    for nom, qte, prix, montant in details:
        print(f"- {nom}: {format_nombre(qte)} × {format_nombre(prix)} F = {format_nombre(montant)} F")

    return f"TOTAL = {format_nombre(total)} F CFA"



# ---------------- COMPRÉHENSION DU FRANÇAIS NATUREL ----------------

def sans_accents(texte):
    texte = unicodedata.normalize("NFD", texte)
    return "".join(c for c in texte if unicodedata.category(c) != "Mn")


def mots_vides(texte):
    """Normalise le texte pour faciliter la détection d'intentions."""
    t = sans_accents(texte.lower())
    t = re.sub(r"[!?;:,'\"“”«»()\[\]]", " ", t)
    t = re.sub(r"(?<=[a-z])-(?=[a-z])", " ", t)   # « sais-tu » -> « sais tu »
    t = re.sub(r"\s+", " ", t).strip()
    return t


def contient_un(t, expressions):
    return any(expr in t for expr in expressions)


def extraire_expression_math(question):
    """
    Extrait une opération d'une phrase naturelle.
    Exemples :
      'combien font 25 fois 17 ?'
      'calcule 230 / 10'
      'j'aimerais savoir combien font 120 + 35'
    """
    t = mots_vides(question)

    # Transformations linguistiques -> opérateurs.
    remplacements = [
        (r"\bfois\b", "*"),
        (r"\bmultiplie(?:r|z)?\b", "*"),
        (r"\bmultiplie\b", "*"),
        (r"\bdivise(?:r|z)?\b", "/"),
        (r"\bdivisé par\b", "/"),
        (r"\bdivisee par\b", "/"),
        (r"\bplus\b", "+"),
        (r"\bmoins\b", "-"),
        (r"\bretire\b", "-"),
        (r"\bsoustrais\b", "-"),
        (r"\bmodulo\b", "%"),
    ]

    expr = t
    for motif, remplacement in remplacements:
        expr = re.sub(motif, remplacement, expr)

    # Retirer les formulations autour du calcul.
    expr = re.sub(
        r"\b(combien font|combien fait|calcule|calculer|fais le calcul de|"
        r"donne moi le resultat de|quel est le resultat de|"
        r"peux tu calculer|peux tu me calculer|j aimerais savoir)\b",
        " ",
        expr
    )

    # Trop de mots restants = vraie question, pas un calcul.
    if len([w for w in expr.split() if re.search(r"[a-z]", w)]) > 1:
        return None

    # Ne garder qu'une expression mathématique raisonnablement sûre.
    expr = re.sub(r"[^0-9+\-*/%.() ]", " ", expr)
    expr = re.sub(r"\s+", " ", expr).strip()

    if re.fullmatch(r"[0-9+\-*/%.() ]+", expr) and any(c.isdigit() for c in expr) and re.search(r"[+\-*/%]", expr):
        return expr
    return None


CLES_PERSONNELLES = {"nom", "prenom", "metier", "profession", "age", "ville", "quartier", "pays",
                     "projet", "adresse", "numero", "email", "ecole", "entreprise", "societe"}


def extraire_retenue_naturelle(question):
    """
    Reconnaît plusieurs façons de demander une mémorisation.
    Exemples :
      'souviens-toi que mon métier est électrotechnicien'
      'garde en mémoire que mon projet est Edison'
      'retiens que j'habite à Bohicon'
      'n'oublie pas que...'
    """
    q = question.strip()
    if "?" in q:
        return None

    motifs = [
        r"(?:souviens[- ]toi|souviens toi)\s+(?:que\s+)?(.+?)\s*=\s*(.+)$",
        r"(?:retiens|retient|garde en memoire|garde en tête|n oublie pas)\s+(?:que\s+)?(.+?)\s*=\s*(.+)$",
        r"(?:souviens[- ]toi|souviens toi|retiens|garde en memoire|n oublie pas)\s+que\s+(.+?)\s+(?:est|c est|ce sont)\s+(.+)$",
        r"(?:mon|ma|mes)\s+(.+?)\s+(?:est|sont)\s+(.+)$",
    ]

    for motif in motifs:
        m = re.match(motif, q, re.I)
        if m:
            cle = m.group(1).strip(" .?!")
            valeur = m.group(2).strip(" .?!")
            if not (cle and valeur and len(cle.split()) <= 3 and len(valeur.split()) <= 8):
                continue
            if motif == motifs[3] and sans_accents(cle.lower()) not in CLES_PERSONNELLES:
                continue
            # "mon métier" -> "métier"
            cle = re.sub(r"^(mon|ma|mes)\s+", "", cle, flags=re.I)
            return cle, valeur
    return None


def reponse_salutation(t):
    mots = t.split()
    if len(mots) <= 5 and (any(m in mots for m in ("bonjour", "bonsoir", "salut", "coucou")) or "bonne journee" in t):
        if "comment vas tu" in t or "ca va" in t:
            return "Je vais bien et je suis prêt à travailler avec toi. Que veux-tu faire ?"
        debut = "Bonsoir" if "bonsoir" in mots else "Bonjour"
        return f"{debut} ! Je suis Edison. Comment vas-tu ? Dis-moi simplement ce dont tu as besoin, même avec une phrase normale."
    return None


def intention_memoire(question):
    t = mots_vides(question)

    if contient_un(t, [
        "que sais tu de moi",
        "qu est ce que tu sais de moi",
        "qu est ce que tu retiens de moi",
        "montre ma memoire",
        "affiche ma memoire",
        "tu te souviens de quoi"
    ]):
        return "AFFICHER"

    # "Est-ce que tu te souviens de mon métier ?"
    if contient_un(t, [
        "tu te souviens de mon metier",
        "tu te rappelles de mon metier",
        "quel est mon metier",
        "je suis quoi comme metier",
        "qu est ce que je fais comme metier"
    ]):
        return "METIER"

    if contient_un(t, [
        "oublie tout",
        "efface ma memoire",
        "supprime ma memoire"
    ]):
        return "OUBLIER_TOUT"

    if t.startswith("oublie ") or t.startswith("efface "):
        return "OUBLIER_UN"

    return None


def intention_electrotechnique(question):
    t = mots_vides(question)

    # Questions naturelles, pas seulement les mots-clés exacts.
    if contient_un(t, ["loi d ohm", "loi ohm", "comment calculer le courant avec la resistance"]):
        return "loi d ohm"

    if contient_un(t, ["puissance en triphase", "puissance triphase", "calculer la puissance triphase"]):
        return "puissance triphase"

    if contient_un(t, ["puissance en monophase", "puissance monophase", "calculer la puissance monophase"]):
        return "puissance monophase"

    if contient_un(t, ["energie electrique", "calculer l energie", "combien d energie"]):
        return "energie"

    if contient_un(t, ["comment fonctionne un api", "c est quoi un api", "qu est ce qu un api", "automate programmable"]):
        return "api"

    if contient_un(t, ["maintenance preventive", "maintenance corrective", "difference entre maintenance preventive et corrective"]):
        return "maintenance"

    if contient_un(t, ["comment diagnostiquer un moteur", "diagnostiquer un moteur", "probleme de moteur"]):
        return "moteur"

    if contient_un(t, ["a quoi sert un disjoncteur", "role du disjoncteur", "disjoncteur"]):
        return "disjoncteur"

    if contient_un(t, ["comment fonctionne un transformateur", "c est quoi un transformateur", "transformateur"]):
        return "transformateur"

    return None


def intention_cout(question):
    t = mots_vides(question)

    return contient_un(t, [
        "combien coute",
        "combien ca coute",
        "calcule le cout",
        "calcule moi le cout",
        "fais le devis",
        "fais moi le devis",
        "calcule le total",
        "quel est le total",
        "additionne mes achats",
        "additionne tout",
        "combien je dois payer"
    ])


CREATEUR = "Edison Ahodede, électrotechnicien"


def reponse_identite(t):
    """Qui est Edison, qui l'a créé."""
    if contient_un(t, ["qui t a cree", "qui t a fait", "qui t a programme", "qui t a concu",
                       "qui t a developpe", "ton createur", "qui est ton createur"]):
        return (f"Mon créateur est {CREATEUR}. Il m'a conçue pour aider à apprendre, "
                "calculer et résoudre des problèmes techniques.")
    if contient_un(t, ["qui es tu", "tu es qui", "presente toi", "comment tu t appelles",
                       "comment t appelles tu", "quel est ton nom", "tu t appelles comment"]):
        return (f"Je suis Edison, une assistante IA francophone créée par {CREATEUR}. "
                "J'aide en électrotechnique, énergies renouvelables, programmation et culture générale, "
                "et je peux retenir ce que tu m'apprends.")
    return None


def reponse_politesse(t):
    """Réponses aux politesses courantes, sans phrase exacte obligatoire."""
    import random
    n = len(t.split())
    if n <= 5 and re.search(r"\bmerci\b", t):
        return random.choice(["Pas de quoi ! 😊", "Avec plaisir ! ⚡", "De rien, c'est normal ! 🤝"])
    if n <= 4 and re.match(r"^(ok|okay|d accord|dac|entendu|bien recu|compris|c est bon|cool|parfait|nickel|top)\b", t):
        return random.choice(["D'accord ! 👍", "Entendu ! ✅", "Très bien ! 😊"])
    if n <= 6 and (re.search(r"\b(blague|humour|drole)\b", t) or "fais moi rire" in t):
        return random.choice(["Pourquoi les électriciens sont-ils toujours calmes ? Parce qu’ils ont de la résistance ! 😄", "Quel est le comble pour un électricien ? De ne pas être au courant ! ⚡😂", "Que dit un fil à un autre fil ? Ne me lâche pas, restons en contact ! 🔌😆"])
    if n <= 7 and "et toi" in t:
        return "Ça va très bien, merci. Je suis prête à t'aider. Que veux-tu apprendre aujourd'hui ?"
    if n <= 6 and contient_un(t, ["comment ca va", "comment vas tu", "comment tu vas",
                                  "tu vas bien", "comment allez vous"]):
        return "Ça va bien, merci ! Et toi, comment vas-tu ?"
    if t in ("ca va", "ca va bien", "je vais bien", "tres bien", "super", "ca va tres bien"):
        return "Content de l'entendre ! Que veux-tu apprendre aujourd'hui ?"
    if n <= 6 and contient_un(t, ["je suis triste", "ca ne va pas", "je vais mal", "pas bien"]):
        return "Je suis désolée que tu te sentes comme ça. Raconte-moi si tu veux, je t'écoute."
    if n <= 5 and contient_un(t, ["au revoir", "a bientot", "a demain", "bye", "ciao"]):
        return "Au revoir ! À bientôt."
    if n <= 4 and "bonne nuit" in t:
        return "Bonne nuit ! Repose-toi bien."
    if n <= 4 and contient_un(t, ["pardon", "desole", "excuse moi"]):
        return "Aucun souci, ce n'est pas grave."
    if t in ("de rien", "avec plaisir", "je t en prie"):
        return "Merci à toi !"
    return None


def commande_apprendre(question):
    """apprends : ta question = ma réponse  -> enrichit la mémoire de connaissances."""
    m = re.match(r"^\s*apprends?\s*(?:que\s*)?:?\s*(.+?)\s*(?:=|->|=>)\s*(.+)$", question, re.I | re.S)
    if not m:
        return None
    cle, valeur = mots_vides(m.group(1)), m.group(2).strip()
    if not cle or not valeur:
        return "Format : apprends : ta question = ma réponse"
    memoire["connaissances"][cle] = valeur
    sauvegarder_memoire(memoire)
    return f"C'est noté, j'ai appris « {m.group(1).strip()} »."


def chercher_apprentissage(question):
    """Cherche dans ce que l'utilisateur a enseigné à Edison."""
    t = mots_vides(question)
    mots_t = t.split()
    meilleur, score = None, 0
    for cle, valeur in memoire["connaissances"].items():
        c = mots_vides(cle)
        if not c:
            continue
        mots_c = [w for w in c.split() if len(w) > 3]
        if (" " + c + " ") in (" " + t + " ") or (mots_c and len(c.split()) <= 6 and all(w in mots_t for w in mots_c)):
            if len(c) > score:
                meilleur, score = valeur, len(c)
    return meilleur


def reponse_naturelle(question):
    """
    Moteur d'intention léger : il ne remplace pas un grand modèle de langage,
    mais il permet à Edison de comprendre de nombreuses formulations françaises.
    """
    t = mots_vides(question)

    # 1. Salutations
    salutation = reponse_salutation(t)
    if salutation:
        return salutation

    # 1b. Ce que l'utilisateur a appris à Edison, identité, politesse
    appris = chercher_apprentissage(question)
    if appris:
        return appris
    ident = reponse_identite(t)
    if ident:
        return ident
    polie = reponse_politesse(t)
    if polie:
        return polie

    # 2. Mémoire
    mem_intent = intention_memoire(question)
    if mem_intent == "AFFICHER":
        return afficher_memoire()

    if mem_intent == "METIER":
        metier = (
            memoire["informations"].get("métier")
            or memoire["informations"].get("metier")
        )
        return f"Tu m'as dit que ton métier est {metier}." if metier else "Tu ne m'as pas encore indiqué ton métier."

    if mem_intent == "OUBLIER_TOUT":
        memoire["informations"].clear()
        sauvegarder_memoire(memoire)
        return "J'ai effacé les informations personnelles enregistrées dans ma mémoire."

    if mem_intent == "OUBLIER_UN":
        morceau = re.sub(r"^(oublie|efface)\s+", "", question, flags=re.I).strip()
        return (
            f"J'ai supprimé « {morceau} » de ma mémoire."
            if oublier(morceau)
            else f"Je ne trouve pas « {morceau} » dans ma mémoire."
        )

    retenue = extraire_retenue_naturelle(question)
    if retenue:
        cle, valeur = retenue
        retenir(cle, valeur)
        return f"D'accord, je vais retenir que {cle} = {valeur}."

    # Cas spécial très naturel : "Je m'appelle X"
    m = re.match(r"^\s*je\s+m['’]?appelle\s+(.+?)\s*[.!?]?$", question, re.I)
    if m:
        nom = m.group(1).strip()
        retenir("nom", nom)
        return f"Enchanté, {nom}. Je peux retenir ton nom pour les prochaines sessions."

    # Questions de connaissances solaires sans valeurs numeriques :
    # les traiter comme des demandes d'explication, pas comme des calculs incomplets.
    if not extraire_toutes_valeurs(question):
        connaissance_solaire = chercher_connaissance_photovoltaique(question)
        if connaissance_solaire:
            return connaissance_solaire

    # 4. Calculs électriques avec unités
    calcul_elec = calcul_electrique(question)
    if calcul_elec:
        return calcul_elec

    # 3. Calculs naturels
    expr = extraire_expression_math(question)
    if expr:
        try:
            resultat = calculer(expr)
            return f"Le résultat est {format_nombre(resultat)}."
        except Exception as e:
            return f"Je comprends que tu veux faire un calcul, mais je n'ai pas pu le terminer : {e}"

    # 4. Coût / devis
    if intention_cout(question):
        return (
            "Oui. Je peux calculer le total. Donne-moi simplement les articles "
            "comme ceci, une ligne par article :\n"
            "fil 10 1000 / prise 2 300 / ampoule 3 1000\n(article, quantité, prix unitaire, séparés par « / »)"
        )

    # 5. Électrotechnique
    intent = intention_electrotechnique(question)
    if intent and not ia_disponible():
        # On mappe vers les clés de la base V6.
        mapping = {
            "loi d ohm": "loi d ohm",
            "puissance triphase": "puissance triphasé",
            "puissance monophase": "puissance monophasé",
            "energie": "energie",
            "api": "api",
            "maintenance": "maintenance",
            "moteur": "moteur",
            "disjoncteur": "disjoncteur",
            "transformateur": "transformateur",
        }
        return CONNAISSANCES[mapping[intent]]

    # 6. Heure/date en langage naturel
    if contient_un(t, [
        "quelle heure est il",
        "tu peux me donner l heure",
        "donne moi l heure",
        "quelle est la date",
        "on est quel jour",
        "quelle date sommes nous"
    ]):
        return datetime.now().strftime("Nous sommes le %d/%m/%Y à %H:%M:%S.")

    # 7. Aide naturelle
    if len(t.split()) <= 8 and contient_un(t, [
        "que peux tu faire",
        "qu est ce que tu peux faire",
        "comment peux tu m aider",
        "comment tu peux m aider",
        "aide moi",
        "aide"
    ]):
        return (
            "Je peux déjà comprendre des phrases naturelles pour :\n"
            "- faire des calculs (« combien font 25 fois 17 ? »)\n"
            "- calculer puissance, tension, courant, résistance, énergie et chute de tension avec les unités\n"
            "- mémoriser des informations (« souviens-toi que mon projet est Edison »)\n"
            "- répondre à des questions d'électrotechnique\n"
            "- calculer des coûts et préparer un devis\n"
            "- expliquer énergies renouvelables, centrales, production de courant\n"
            "- t'apprendre les bases du code (Python, HTML) et la culture générale\n"
            "- retenir ce que tu m'apprends (apprends : question = réponse)\n"
            "- te donner la date et l'heure\n"
            "- écouter ta voix et répondre vocalement sur Android\n"
            "- répondre à presque toutes tes questions avec l'IA (tape : ia cle TA_CLE_API).\n\n"
            "Tu n'es donc plus obligé d'utiliser des commandes exactes."
        )

    if "merci" in t and len(t.split()) <= 6:
        return "Avec plaisir. On continue."

    # Questions solaires : reponse locale hors ligne, meme si la cle IA est absente.
    connaissance_solaire = chercher_connaissance_photovoltaique(question)
    if connaissance_solaire:
        return connaissance_solaire

    return None


# ---------------- INTELLIGENCE ARTIFICIELLE (API CLAUDE) ----------------

API_URL = "https://api.anthropic.com/v1/messages"
MODELE_IA = "claude-haiku-5-5"   # rapide et économique ; "claude-sonnet-5-5" = réponses plus poussées
CLE_FILE = "cle_api.txt"
MAX_TOKENS_IA = 700
DELAI_IA = 45

CONVERSATION = []   # échanges de la session en cours


class ErreurIA(Exception):
    pass


def lire_cle_api():
    cle = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if cle:
        return cle
    try:
        with open(CLE_FILE, "r", encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def enregistrer_cle_api(cle):
    with open(CLE_FILE, "w", encoding="utf-8") as f:
        f.write(cle.strip())


def ia_disponible():
    return bool(lire_cle_api())


def prompt_systeme():
    infos = memoire["informations"]
    profil = "\n".join(f"- {k} : {v}" for k, v in infos.items()) or "(rien d'enregistré)"
    return (
        "Tu es Edison, une assistante IA francophone dans une application Android. "
        "Ton domaine principal est l'électrotechnique : installations électriques, moteurs, "
        "câblage, protections, automatismes, maintenance, énergie solaire, vidéosurveillance. "
        "Ton créateur est " + CREATEUR + ". Tu enseignes aussi les énergies renouvelables, les centrales et systèmes énergétiques, "
        "la programmation (Python, HTML), la culture générale, la politesse et les salutations.\n"
        "Notre objectif : devenir une vraie assistante IA francophone qui aide à apprendre l'électrotechnique, le solaire, les énergies renouvelables, le code et la culture générale, avec politesse et mémoire. "
        "Ton créateur est un électrotechnicien qui rêve de bâtir quelque chose de plus grand ; reste fidèle à ce but.\n"
        "Tu peux aussi aider sur d'autres sujets (rédaction, études, vie pratique).\n"
        "Règles : réponds en français simple, clair et court (petit écran) ; donne les formules "
        "et les étapes quand c'est utile ; pose une seule question si une information essentielle "
        "manque ; rappelle la sécurité (consignation, vérification d'absence de tension) seulement "
        "quand le risque est réel ; si tu n'es pas sûre, dis-le. "
        "Écris en texte brut : pas de tableaux, pas de Markdown (l'affichage ne l'interprète pas).\n"
        "Informations que l'utilisateur t'a demandé de retenir :\n" + profil
    )


def demander_ia(question):
    cle = lire_cle_api()
    if not cle:
        raise ErreurIA("Aucune clé API configurée.")

    CONVERSATION.append({"role": "user", "content": question})
    del CONVERSATION[:-24]
    messages = CONVERSATION[-12:]
    while messages and messages[0]["role"] != "user":
        messages = messages[1:]

    corps = json.dumps({
        "model": MODELE_IA,
        "max_tokens": MAX_TOKENS_IA,
        "system": prompt_systeme(),
        "messages": messages,
    }).encode("utf-8")

    requete = urllib.request.Request(
        API_URL, data=corps, method="POST",
        headers={
            "content-type": "application/json",
            "x-api-key": cle,
            "anthropic-version": "2023-06-01",
        },
    )

    try:
        with urllib.request.urlopen(requete, timeout=DELAI_IA) as r:
            data = json.loads(r.read().decode("utf-8"))
        texte = "".join(
            b.get("text", "") for b in data.get("content", []) if b.get("type") == "text"
        ).strip()
        if not texte:
            raise ErreurIA("L'IA a renvoyé une réponse vide.")
    except urllib.error.HTTPError as e:
        CONVERSATION.pop()
        if e.code == 401:
            raise ErreurIA("Clé API refusée. Refais : ia cle TA_CLE_API")
        if e.code == 429:
            raise ErreurIA("Trop de demandes ou crédit épuisé. Réessaie dans un instant.")
        if e.code >= 500:
            raise ErreurIA("Le service IA est surchargé. Réessaie dans un instant.")
        raise ErreurIA(f"Erreur du service IA (code {e.code}).")
    except (urllib.error.URLError, OSError):
        CONVERSATION.pop()
        raise ErreurIA("Pas de connexion internet : je réponds avec mes connaissances locales.")
    except ErreurIA:
        CONVERSATION.pop()
        raise
    except (ValueError, KeyError):
        CONVERSATION.pop()
        raise ErreurIA("Réponse illisible du service IA.")

    CONVERSATION.append({"role": "assistant", "content": texte})
    return texte


def commande_ia(question):
    """Commandes : ia cle XXX / ia statut / ia reset."""
    m = re.match(r"^\s*ia\s+cl[eé]\s+(\S+)\s*$", question, re.I)
    if m:
        cle = m.group(1).strip("\"'")
        enregistrer_cle_api(cle)
        avert = "" if cle.startswith("sk-ant-") else (
            "\nAttention : une clé commence normalement par sk-ant-. Vérifie avec : ia statut")
        return f"Clé enregistrée ({len(cle)} caractères). Teste avec une question." + avert
    t = normaliser(question)
    if t == "ia statut":
        cle = lire_cle_api()
        if not cle:
            return "IA désactivée (tape : ia cle TA_CLE_API)."
        masque = cle[:7] + "…" + cle[-4:]
        return (f"IA activée. Clé : {masque} ({len(cle)} caractères). "
                f"Modèle : {MODELE_IA}. Messages en contexte : {len(CONVERSATION)}.")
    if t in ("ia reset", "nouvelle conversation"):
        CONVERSATION.clear()
        return "Conversation IA réinitialisée."
    return None


def devis_en_ligne(question):
    """Devis sur un seul message : fil 10 1000 / prise 2 300 / ampoule 3 1000"""
    parties = [p.strip() for p in re.split(r"[\n/]+", question) if p.strip()]
    if len(parties) < 2 or any(parser_ligne_article(p) is None for p in parties):
        return None
    total, details = calculer_liste_cout(parties)
    lignes = [f"- {n} : {format_nombre(q)} × {format_nombre(p)} F = {format_nombre(m)} F"
              for n, q, p, m in details]
    return "DÉTAIL\n" + "\n".join(lignes) + f"\n\nTOTAL = {format_nombre(total)} F CFA"


def traiter(question):
    appr = commande_apprendre(question)
    if appr is not None:
        return appr

    cmd = commande_ia(question)
    if cmd is not None:
        return cmd

    devis = devis_en_ligne(question)
    if devis:
        return devis

    # Nouvelle couche : français naturel.
    naturel = reponse_naturelle(question)
    if naturel is not None:
        return naturel

    # Compatibilité avec les anciennes commandes V6.
    t = normaliser(question)

    if t in ("quitter", "exit", "quit"):
        return "__QUIT__"

    if t == "mémoire" or t == "memoire":
        return afficher_memoire()

    if t.startswith("calc "):
        expr = question[5:].strip()
        try:
            resultat = calculer(expr)
            return f"{expr} = {format_nombre(resultat)}"
        except Exception as e:
            return f"Je ne peux pas effectuer ce calcul : {e}"

    m = re.match(r"^\s*retiens\s+que\s+(.+?)\s*=\s*(.+)\s*$", question, re.I)
    if m:
        cle, valeur = m.group(1), m.group(2)
        retenir(cle, valeur)
        return f"D'accord. Je retiens : {cle.strip()} = {valeur.strip()}."

    if t in ("heure", "date", "quelle heure est il", "quelle heure est-il"):
        return datetime.now().strftime("Nous sommes le %d/%m/%Y à %H:%M:%S.")

    # Ancienne recherche par mots-clés en dernier recours.
    if not ia_disponible():
        connaissance = chercher_connaissance(question)
        if connaissance:
            return connaissance

    if re.fullmatch(r"[0-9\s\+\-\*\/\%\(\)\.,×÷\^]+", question.strip()):
        try:
            resultat = calculer(question)
            return f"{question} = {format_nombre(resultat)}"
        except Exception:
            pass

    erreur = ""
    if ia_disponible():
        try:
            return demander_ia(question)
        except ErreurIA as e:
            erreur = str(e) + "\n\n"
            connaissance = chercher_connaissance(question)
            if connaissance:
                return erreur + connaissance

    return erreur + (
        "Je n'ai pas encore assez de connaissances pour répondre à cette demande. "
        "Essaie de me l'expliquer autrement"
        + ("." if ia_disponible() else ", ou active l'IA avec : ia cle TA_CLE_API.")
    )


# ---------------- INTERFACE GRAPHIQUE ANDROID / PYDROID 3 ----------------

try:
    import tkinter as tk
    from tkinter import scrolledtext, messagebox
except ImportError:
    tk = None


class EdisonGUI:
    """Interface légère, tactile et compatible avec Tkinter/Pydroid 3."""

    def __init__(self, root):
        self.root = root
        self.occupe = False
        self.file = queue.Queue()
        self.voice_file = queue.Queue()
        self.marque_attente = "end"
        self.voix_active = True
        initialiser_voix()
        self.root.title("Edison AI")
        self.root.geometry("420x720")
        self.root.minsize(320, 500)

        self.font_main = ("DejaVu Sans", 12)
        self.font_small = ("DejaVu Sans", 10)
        self.font_title = ("DejaVu Sans", 18, "bold")

        # Couleurs sobres pour une utilisation confortable sur téléphone.
        self.bg = "#101418"
        self.panel = "#1a2026"
        self.text = "#f2f4f5"
        self.muted = "#aeb7bf"
        self.accent = "#2f8cff"
        self.user_bg = "#26313b"
        self.ai_bg = "#182a22"

        self.root.configure(bg=self.bg)

        # En-tête
        header = tk.Frame(root, bg=self.panel, padx=12, pady=10)
        header.pack(fill="x")

        title = tk.Label(
            header,
            text="EDISON",
            font=self.font_title,
            bg=self.panel,
            fg=self.text
        )
        title.pack(side="left")

        subtitle = tk.Label(
            header,
            text="Assistant électrotechnique",
            font=self.font_small,
            bg=self.panel,
            fg=self.muted
        )
        subtitle.pack(side="left", padx=(10, 0), pady=(7, 0))

        # Zone de conversation
        self.chat = scrolledtext.ScrolledText(
            root,
            wrap=tk.WORD,
            font=self.font_main,
            bg=self.bg,
            fg=self.text,
            insertbackground=self.text,
            relief="flat",
            padx=10,
            pady=10
        )
        self.chat.configure(state="disabled")

        self.chat.tag_configure(
            "user",
            background=self.user_bg,
            foreground=self.text,
            lmargin1=8,
            lmargin2=8,
            rmargin=8,
            spacing1=5,
            spacing3=8
        )
        self.chat.tag_configure(
            "edison",
            background=self.ai_bg,
            foreground=self.text,
            lmargin1=8,
            lmargin2=8,
            rmargin=8,
            spacing1=5,
            spacing3=8
        )
        self.chat.tag_configure(
            "system",
            foreground=self.muted,
            font=self.font_small
        )

        # Suggestions rapides : boutons assez grands pour le tactile.
        quick = tk.Frame(root, bg=self.bg)

        for label, text_cmd in [
            ("Électricité", "Explique-moi la loi d'Ohm"),
            ("Calcul", "Combien font 25 fois 17 ?"),
            ("Mémoire", "Que sais-tu de moi ?"),
        ]:
            b = tk.Button(
                quick,
                text=label,
                command=lambda c=text_cmd: self.envoyer_texte(c),
                font=self.font_small,
                bg=self.panel,
                fg=self.text,
                activebackground=self.accent,
                activeforeground="white",
                relief="flat",
                padx=8,
                pady=8
            )
            b.pack(side="left", expand=True, fill="x", padx=2)

        # Commandes vocales
        voice = tk.Frame(root, bg=self.bg)

        self.voice_button = tk.Button(
            voice,
            text="🎤 Parler",
            command=self.demarrer_ecoute,
            font=self.font_small,
            bg=self.panel,
            fg=self.text,
            activebackground=self.accent,
            activeforeground="white",
            relief="flat",
            padx=10,
            pady=8
        )
        self.voice_button.pack(side="left", expand=True, fill="x", padx=2)

        self.voice_toggle = tk.Button(
            voice,
            text="🔊 Voix : ON",
            command=self.basculer_voix,
            font=self.font_small,
            bg=self.panel,
            fg=self.text,
            activebackground=self.accent,
            activeforeground="white",
            relief="flat",
            padx=10,
            pady=8
        )
        self.voice_toggle.pack(side="left", expand=True, fill="x", padx=2)

        voice.pack(side="bottom", fill="x", padx=8, pady=3)

        # Zone de saisie
        bottom = tk.Frame(root, bg=self.panel, padx=8, pady=8)

        self.entry = tk.Entry(
            bottom,
            font=self.font_main,
            bg="#222a31",
            fg=self.text,
            insertbackground=self.text,
            relief="flat"
        )
        self.entry.pack(side="left", fill="x", expand=True, ipady=10, padx=(0, 6))
        self.entry.bind("<Return>", self.envoyer)

        send = tk.Button(
            bottom,
            text="OK",
            command=self.envoyer,
            font=("TkDefaultFont", 13, "bold"),
            bg=self.accent,
            fg="white",
            activebackground=self.accent,
            activeforeground="white",
            relief="flat",
            width=5,
            pady=5
        )
        send.pack(side="right")

        # Ordre d'empilement : saisie, commandes vocales, suggestions, puis conversation.
        bottom.pack(side="bottom", fill="x")
        voice.pack(side="bottom", fill="x", padx=8, pady=3)
        quick.pack(side="bottom", fill="x", padx=8, pady=3)
        self.chat.pack(side="top", fill="both", expand=True, padx=8, pady=(8, 4))

        # Message d'accueil.
        self.afficher(
            "Edison",
            "Bonjour ! Tu peux me parler normalement. "
            "Essaie par exemple : « Combien font 25 fois 17 ? » "
            "ou « Explique-moi comment diagnostiquer un moteur ». "
            "Tu peux aussi appuyer sur « 🎤 Parler » pour lui parler.",
            "edison"
        )

        if not ia_disponible():
            self.afficher(
                "Edison",
                "Mode IA désactivé. Pour l'activer, tape : ia cle TA_CLE_API",
                "system"
            )

        if initialiser_voix() is None:
            self.voice_button.configure(
                text="🎤 Voix indisponible",
                state="disabled"
            )
            self.voice_toggle.configure(
                text="🔇 Voix indisponible",
                state="disabled"
            )

        self.entry.focus_set()

    def afficher(self, auteur, texte, tag):
        self.chat.configure(state="normal")
        self.chat.insert("end", f"{auteur}\n", tag)
        self.chat.insert("end", f"{texte}\n\n", tag)
        self.chat.configure(state="disabled")
        self.chat.see("end")

    def basculer_voix(self):
        self.voix_active = not self.voix_active
        self.voice_toggle.configure(
            text="🔊 Voix : ON" if self.voix_active else "🔇 Voix : OFF"
        )
        if self.voix_active:
            parler("La voix d'Edison est activée.")
        else:
            # On ne lit volontairement rien ici : le bouton sert justement à couper la voix.
            pass

    def demarrer_ecoute(self):
        if self.occupe:
            return

        # La reconnaissance vocale Android est bloquante : on la lance dans un thread.
        self.voice_button.configure(state="disabled", text="🎤 Écoute…")
        self.afficher("Système", "Edison écoute… parle maintenant.", "system")
        threading.Thread(target=self._ecoute_vocale, daemon=True).start()

    def _ecoute_vocale(self):
        texte, erreur = ecouter_voix()
        self.voice_file.put((texte, erreur))
        self.root.after(100, self._verifier_vocal)

    def _verifier_vocal(self):
        try:
            texte, erreur = self.voice_file.get_nowait()
        except queue.Empty:
            self.root.after(100, self._verifier_vocal)
            return

        self.voice_button.configure(state="normal", text="🎤 Parler")

        if erreur:
            self.afficher("Système", erreur, "system")
            return

        if texte:
            self.envoyer_texte(texte)

    def envoyer(self, event=None):
        texte = self.entry.get().strip()
        if texte:
            self.envoyer_texte(texte)
        return "break"

    def envoyer_texte(self, texte):
        if self.occupe:
            return
        self.entry.delete(0, "end")

        affiche = texte
        if re.match(r"^\s*ia\s+cl[eé]\s+", texte, re.I):
            affiche = "ia cle ••••••••"   # ne jamais afficher la clé
        self.afficher("Toi", affiche, "user")

        self.occupe = True
        self.chat.configure(state="normal")
        self.marque_attente = self.chat.index("end-1c")
        self.chat.insert("end", "Edison réfléchit…\n\n", "system")
        self.chat.configure(state="disabled")
        self.chat.see("end")

        threading.Thread(target=self._travail, args=(texte,), daemon=True).start()
        self.root.after(100, self._verifier)

    def _travail(self, texte):
        try:
            reponse = traiter(texte)
        except Exception as exc:
            reponse = f"Une erreur est survenue. Détail technique : {exc}"
        self.file.put(reponse)

    def _verifier(self):
        try:
            reponse = self.file.get_nowait()
        except queue.Empty:
            self.root.after(100, self._verifier)
            return

        self.occupe = False
        self.chat.configure(state="normal")
        self.chat.delete(self.marque_attente, "end")
        self.chat.configure(state="disabled")

        if reponse == "__QUIT__":
            self.root.destroy()
            return
        self.afficher("Edison", reponse, "edison")
        if self.voix_active:
            threading.Thread(target=parler, args=(reponse,), daemon=True).start()


def lancer_edison():
    if tk is None:
        raise RuntimeError(
            "Tkinter n'est pas disponible dans cet environnement Python. "
            "Sur Pydroid 3, installe/active le support Tkinter si nécessaire."
        )

    root = tk.Tk()
    EdisonGUI(root)
    root.mainloop()


if __name__ == "__main__":
    lancer_edison()
