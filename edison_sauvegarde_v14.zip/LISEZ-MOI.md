# Edison IA — carnet de projet (sauvegarde mise à jour le 10 octobre 2026)

## Qui et pourquoi
- Créateur : Edison Ahodede, électrotechnicien (Bénin).
- Il rêve de bâtir quelque chose de plus grand. Il a choisi Thomas Edison comme idole et veut être comme lui.
- Edison IA ne doit jamais quémander (pas de « cherche des collaborateurs / du soutien »).

## Objectifs d'Edison IA (à ne pas oublier)
1. Aider à apprendre et résoudre des problèmes d'électricité, d'électrotechnique et de solaire.
2. Enseigner les énergies renouvelables, les centrales, le code et la culture générale.
3. Respecter les bonnes manières (salutations, politesse).
4. Retenir ce qu'on lui apprend (commande Python : `apprends : question = réponse`).
5. Devenir une vraie assistante IA : comprendre le sens des questions, calculer, écouter et parler.

## Où est tout
- Application en ligne : https://electotechnique058-eng.github.io/edison-ia/
- Code sur GitHub : https://github.com/electotechnique058-eng/edison-ia
- Dans ce dossier (les fiches sont déjà dans index.html et dans le fichier Python) :
  - `edison-ia-site/` : les 5 fichiers de l'application (index.html, manifest.json, sw.js, icon-192.png, icon-512.png)
  - `python/edison_android_gui_v12_savoirs.py` : version Python (Pydroid 3)

## Mettre à jour l'application
1. Remplacer les fichiers dans le dépôt GitHub : Add file > Upload files > mêmes noms > Commit changes.
2. Attendre 1 à 2 minutes, puis rouvrir l'application avec Internet.
3. Nom sous l'icône : « Edison IA » (manifest.json).

## Ce qu'Edison sait déjà
- Électrotechnique : câbles, disjoncteurs, moteurs (direct, étoile-triangle), schémas, dépannage, mesure, sécurité, couleurs des fils, normes.
- Solaire : dimensionnement, régulateur, vidéosurveillance, antenne parabolique.
- Énergie : renouvelables, production de courant, centrales, rendement, stockage.
- Code : Python, HTML/CSS/JS, débogage, Arduino.
- Culture générale : salutations, politesse, Bénin, géographie.
- Schémas affichés : démarrage direct, étoile-triangle, va-et-vient, installation solaire.
- Voix : micro et lecture (Chrome, Internet nécessaire pour comprendre la voix).
- Histoire et personnes : famille AHODEDE d'Abomey (ancêtres amenés par le roi Guezo, fidèles et prêtres de Fâ), roi Guezo (faits vérifiés), Rodriguez Paul (BTP / génie civil).
- Réponses courtes à merci / ok, et des blagues avec emojis.

- Physique (chapitre M1, cinématique) : fiches de cours (repères, vitesse, accélération, MRU, MRUV, MCU, unités S.I.) et calculs avec étapes (v = at + v0, x = ½at² + v0t + x0, v² − v0² = 2a(x − x0), v = Rω, a = v²/R, T, N), rencontre de deux mobiles, dérivées de x(t).

## Idées pour la suite
- Plus de fiches (prix du matériel au Bénin, cours, exercices corrigés).
- Schémas : inversion de sens d'un moteur, tableau électrique d'une maison.
- Quiz d'entraînement.
- Lecture d'images (demande une IA avec clé API).

## Sécurité
- Le dépôt GitHub est public : ne jamais y mettre de clé API ni de mot de passe.
- Vérifier chaque valeur technique avec les cours et les normes locales avant de l'appliquer.

## Pour continuer avec Claude (même après changement de téléphone)
1. Se connecter au même compte Claude : les conversations restent dans le compte.
2. Dans une nouvelle conversation, envoyer ce dossier (ou au moins `index.html` et ce fichier LISEZ-MOI) et écrire ce qu'on veut ajouter.
3. Garder une copie de ce dossier dans un endroit sûr (Google Drive, e-mail, carte mémoire).
